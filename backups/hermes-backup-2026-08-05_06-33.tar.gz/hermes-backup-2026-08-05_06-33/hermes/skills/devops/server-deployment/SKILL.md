---
name: server-deployment
description: "Deploy Linux services with systemd, Docker, and backups."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [server, deployment, systemd, docker, devops, monitoring]
    related_skills: [github-repo-management, hermes-agent]
---

# Server Deployment

Patterns for deploying and managing services on Linux servers.

## Systemd Services

```bash
cat > /etc/systemd/system/svc.service << 'EOF'
[Unit]
Description=Service
After=network.target
[Service]
Type=simple
ExecStart=/path/to/binary
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload && systemctl enable --now svc
```

## Docker Deployment

```bash
docker run -d --name svc --restart unless-stopped \
  --env-file .env -p 8080:8080 image:latest
```

## Monitoring

```bash
#!/bin/bash
if ! systemctl is-active --quiet svc; then
    systemctl restart svc
    echo "[$(date)] Restarted svc" >> /var/log/watchdog.log
fi
```

## Backups

```bash
DATE=$(date +%Y-%m-%d)
tar -czf /root/backups/backup-${DATE}.tar.gz /path/to/configs
ls -t /root/backups/backup-*.tar.gz | tail -n +8 | xargs rm -f
```

## Pitfalls

### Supabase New Key Format

Old `supabase` Python lib fails with `sb_publishable_`/`sb_secret_` keys. Use REST API:

```python
import httpx
class SupabaseREST:
    def __init__(self, url, key):
        self.url = url.rstrip('/')
        self.headers = {"apikey": key, "Authorization": f"Bearer {key}"}
    def table(self, name):
        return TableQuery(f"{self.url}/rest/v1", self.headers, name)
```

### V2RayDAR Portable Mode

Config location: `v2raydar_data/configs.yaml` (not root `configs.yaml`).

### Graphify Commands

Use `graphify extract`, not `graphify run`.

### GitHub Token Scope

If token lacks `repo` scope: use existing repo, Gists, or save locally.
