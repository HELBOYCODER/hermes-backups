# V2RayDAR Public Access & Monitoring

## Making V2RayDAR Accessible from Public IP

### Problem
By default, V2RayDAR binds to `127.0.0.1` (local only). Two changes are required for public access.

### Solution
Edit `v2raydar_data/configs.yaml` (NOT the root `configs.yaml` in `--portable` mode):

```yaml
bind: 0.0.0.0:27141        # Changed from 127.0.0.1
sharing:
  enabled: true             # MUST be true for public access
```

Restart after editing:
```bash
systemctl restart v2raydar
```

### Verify public access
```bash
# Check it's listening on 0.0.0.0
ss -tlnp | grep 27141

# Test from public IP
curl -s -o /dev/null -w "HTTP Status: %{http_code}\n" http://YOUR_PUBLIC_IP:27141/health
```

## Config Change Monitoring

### Script: `/root/V2RayDAR/scripts/monitor.sh`
```bash
#!/bin/bash
V2RAYDAR_URL="http://127.0.0.1:27141/subscription"
HASH_FILE="/root/V2RayDAR/v2raydar_data/last_hash.txt"
LOG_FILE="/root/V2RayDAR/v2raydar_data/monitor.log"

mkdir -p /root/V2RayDAR/v2raydar_data

CURRENT_HASH=$(curl -s "$V2RAYDAR_URL" | md5sum | awk '{print $1}')

if [ ! -f "$HASH_FILE" ]; then
    echo "$CURRENT_HASH" > "$HASH_FILE"
    echo "[$(date)] First run - hash saved: $CURRENT_HASH" >> "$LOG_FILE"
    exit 0
fi

SAVED_HASH=$(cat "$HASH_FILE")
if [ "$CURRENT_HASH" != "$SAVED_HASH" ]; then
    echo "[$(date)] Configs changed! Refreshing..." >> "$LOG_FILE"
    echo "$CURRENT_HASH" > "$HASH_FILE"
    systemctl restart v2raydar
    echo "[$(date)] Service restarted" >> "$LOG_FILE"
else
    echo "[$(date)] No changes detected" >> "$LOG_FILE"
fi
```

### Cron job setup
```
*/10 * * * * /root/V2RayDAR/scripts/monitor.sh
```

## systemd Service

```ini
[Unit]
Description=V2RayDAR - V2Ray Detection And Reconnaissance
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/V2RayDAR
ExecStart=/root/V2RayDAR/v2raydar --no-tui --portable
Restart=always
RestartSec=30
Environment=HOME=/root

[Install]
WantedBy=multi-user.target
```

## Quick Reference

| Endpoint | Format | URL |
|----------|--------|-----|
| Subscription (base64) | V2Ray share-links | `http://IP:27141/subscription` |
| Mihomo YAML | Clash/Mihomo config | `http://IP:27141/mihomo.yaml` |
| Plain text | sing-box compatible | `http://IP:27141/subscription.txt` |
| Health check | Status check | `http://IP:27141/health` |
