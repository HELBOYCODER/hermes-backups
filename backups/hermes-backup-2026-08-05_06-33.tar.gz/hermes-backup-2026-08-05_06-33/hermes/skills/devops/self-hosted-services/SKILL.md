---
name: self-hosted-services
description: "Deploy self-hosted services via Docker and systemd (SearXNG, V2RayDAR, etc.)."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [docker, self-hosted, searxng, v2raydar, devops, deployment, systemd]
  related_skills: [hermes-agent]
---

# Self-Hosted Service Deployment

Deploy, configure, and maintain self-hosted services on Linux servers using Docker.

## General Workflow

1. **Check prerequisites**: Docker, docker-compose, available ports, disk/RAM
2. **Pull image**: `docker pull <image>` or use docker-compose
3. **Create config**: Mount custom config files via volumes
4. **Run container**: `docker run -d` or `docker compose up -d`
5. **Verify**: Check logs, test HTTP endpoint
6. **Autostart**: Set `restart: unless-stopped` or create systemd service

## Docker Installation (if not present)

```bash
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker
```

## Common Pitfalls

### Docker Compose `version` attribute
Modern Docker Compose ignores the `version` key. Omit it to avoid warnings:
```yaml
# WRONG
version: '3.8'
services:
  app: ...

# RIGHT
services:
  app: ...
```

### Container restart from inside itself
You cannot `docker restart` or `systemctl restart` a container from a command running inside that container — SIGTERM propagates and kills the command first. Use a separate shell or systemd timer.

### Config file mounts
- Always verify mounted configs are valid: `docker exec <container> cat /etc/app/config.yml`
- Test with minimal config first, then add features incrementally
- Check container logs immediately after start: `docker logs <container> --tail 20`

## systemd Integration

### Simple service
```ini
[Unit]
Description=My Service
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/my-command
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### Watchdog timer (periodic health check)
```ini
# my-watchdog.timer
[Unit]
Description=Run watchdog every 60s

[Timer]
OnBootSec=30
OnUnitActiveSec=60

[Install]
WantedBy=timers.target
```

```ini
# my-watchdog.service
[Unit]
Description=Watchdog check

[Service]
Type=oneshot
ExecStart=/path/to/check-script.sh
```

Enable: `systemctl enable --now my-watchdog.timer`

## SearXNG Deployment

See `references/searxng-deployment.md` for full walkthrough with all pitfalls.

## V2RayDAR Deployment

See `references/v2raydar-deployment.md` for installation, systemd setup, and configuration.
See `references/v2raydar-public-access.md` for public access setup and config change monitoring.

**Critical pitfall:** `--portable` mode reads config from `v2raydar_data/configs.yaml`, NOT the root `configs.yaml`. Always edit the correct file.

## HaveAll Deployment

See `references/haveall-deployment.md` for Telegram bot + Supabase setup.

**Critical pitfall:** Supabase's new key formats (`sb_publishable_`, `sb_secret_`) are incompatible with the Python `supabase` library. Use a custom REST client (see `references/supabase-key-format-pitfall.md`).

**Database setup:** Tables must be created via SQL Editor or direct PostgreSQL connection (`psql -h db.PROJECT.supabase.co`). Bot fails with 404 on REST API if tables don't exist.

## Supabase Key Format

See `references/supabase-key-format-pitfall.md` if you encounter `Invalid API key` errors with Supabase's new key formats.

Quick start:
```bash
docker run -d --name searxng \
  -p 8080:8080 \
  -v /path/to/settings.yml:/etc/searxng/settings.yml \
  -e SEARXNG_BASE_URL=http://localhost:8080/ \
  --restart unless-stopped \
  searxng/searxng:latest
```
