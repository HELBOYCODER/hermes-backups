"""
Supabase REST API Client - replaces the old supabase Python library
Uses the new sb_secret_ key format directly with PostgREST
"""

import os
import httpx
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

class QueryResult:
    """Result object that mimics supabase response"""
    def __init__(self, data: list):
        self.data = data

class TableQuery:
    """Query builder for a single table"""
    
    def __init__(self, rest_url: str, headers: dict, table_name: str):
        self.rest_url = rest_url
        self.headers = headers
        self.table_name = table_name
        self._filters = []
        self._order = None
        self._limit = None
        self._select = "*"
        self._method = "GET"
        self._body = None
    
    def select(self, *columns):
        """Select columns"""
        if columns:
            self._select = ",".join(columns)
        else:
            self._select = "*"
        return self
    
    def insert(self, data):
        """Insert data"""
        self._method = "POST"
        if isinstance(data, dict):
            data = [data]
        self._body = data
        return self
    
    def update(self, data):
        """Update data"""
        self._method = "PATCH"
        self._body = data
        return self
    
    def delete(self):
        """Delete rows"""
        self._method = "DELETE"
        return self
    
    def eq(self, column: str, value: Any):
        """Equals filter"""
        self._filters.append((column, "eq", value))
        return self
    
    def neq(self, column: str, value: Any):
        """Not equals filter"""
        self._filters.append((column, "neq", value))
        return self
    
    def order(self, column: str, desc: bool = False):
        """Order results"""
        direction = "desc" if desc else "asc"
        self._order = f"{column}.{direction}"
        return self
    
    def limit(self, count: int):
        """Limit results"""
        self._limit = count
        return self
    
    def execute(self):
        """Execute the query and return QueryResult"""
        params = {}
        
        if self._method == "GET":
            params["select"] = self._select
            
            # Apply filters
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            
            # Order
            if self._order:
                params["order"] = self._order
            
            # Limit via Range header
            headers = dict(self.headers)
            if self._limit:
                headers["Range"] = f"0-{self._limit - 1}"
            
            response = httpx.get(
                f"{self.rest_url}/{self.table_name}",
                headers=headers,
                params=params
            )
            response.raise_for_status()
            return QueryResult(response.json())
        
        elif self._method == "POST":
            headers = dict(self.headers)
            headers["Prefer"] = "return=representation"
            
            response = httpx.post(
                f"{self.rest_url}/{self.table_name}",
                headers=headers,
                json=self._body
            )
            response.raise_for_status()
            return QueryResult(response.json())
        
        elif self._method == "PATCH":
            headers = dict(self.headers)
            headers["Prefer"] = "return=representation"
            
            # Apply filters to WHERE clause using params
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            
            response = httpx.patch(
                f"{self.rest_url}/{self.table_name}",
                headers=headers,
                json=self._body,
                params=params
            )
            response.raise_for_status()
            return QueryResult(response.json())
        
        elif self._method == "DELETE":
            headers = dict(self.headers)
            headers["Prefer"] = "return=representation"
            
            # Apply filters to WHERE clause
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            
            response = httpx.delete(
                f"{self.rest_url}/{self.table_name}",
                headers=headers,
                params=params
            )
            response.raise_for_status()
            return QueryResult(response.json())


class SupabaseRESTClient:
    """Direct REST API client for Supabase"""
    
    def __init__(self, url: str, key: str):
        self.url = url.rstrip('/')
        self.key = key
        self.rest_url = f"{self.url}/rest/v1"
        self.headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json"
        }
    
    def table(self, table_name: str):
        """Return a table query builder"""
        return TableQuery(self.rest_url, self.headers, table_name)


def create_client(url: str, key: str):
    """Create a Supabase REST client"""
    return SupabaseRESTClient(url, key)
