---
name: hermes-academy
description: "Create lessons for completed tasks via hermes-academy CLI."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [learning, lessons, documentation, academy]
---

# Hermes Academy — Auto-Lesson Generation

After completing ANY significant task (bug fix, install, deploy, refactor, configuration), generate a structured lesson so the process is teachable and searchable.

## When to Use

- After finishing a project or installation
- After solving a non-trivial bug
- After deploying or configuring a service
- After any task that took 3+ tool calls or had interesting learnings

## How to Generate

### 1. Create the lesson file

Lessons live at `~/.hermes/academy/<Category>/<id>.md`

Required format:

```markdown
<!-- HERMES ACADEMY LESSON -->
ID: <unique-id>
Title: <short title>
Category: <Linux|Rust|Cargo|Git|Networking|Docker|Security|DevOps|AI|Architecture|Performance|UI|Backend|Frontend|Database>
Difficulty: <Beginner|Intermediate|Advanced>
Created: <unix timestamp>
TimeSavedMin: <minutes saved>
HermesSec: <seconds hermes took>
Summary: <one-line summary>
Concepts: <comma, separated>
Related: <comma, separated>

---

# Summary
...

# Problem
...

# Investigation
...

# Solution
...

# Technical Explanation
...

# Why This Works
...

# Professional Best Practices
...

# Common Mistakes
...

# Alternative Solutions
...

# Commands Used
```bash
...
```

# Files Modified
- path1
- path2

# Before vs After
Before:
```
...
```
After:
```
...
```

# Key Concepts Learned
✔ concept1
✔ concept2

# Difficulty
<level>

# Time Saved
Estimated manual debugging time: X minutes
Hermes solved it in: Y seconds

# Related Topics
- ...

# References
- https://...

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. Question 1?
2. Question 2?
```

### 2. Verify

```bash
hermes-academy list                    # shows the new lesson
hermes-academy search "<keyword>"      # full-text search works
hermes-academy dashboard               # progress updates
```

## Pitfalls

- Use `date +%s` for the Created timestamp
- Keep IDs kebab-case and unique (e.g. `projectname-yyyymmdd`)
- Category must be one of the 15 valid ones or the CLI won't group it properly
- Write lessons in the language the user communicates in (Persian/Farsi for this user)
- After creating lessons, run the backup script so they're pushed to GitHub:
  `bash /root/scripts/backup.sh` (already includes ~/.hermes/academy)
