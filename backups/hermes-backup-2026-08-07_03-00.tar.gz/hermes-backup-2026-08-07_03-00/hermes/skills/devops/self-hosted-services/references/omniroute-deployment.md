# OmniRoute Deployment Reference

## What It Is
OmniRoute is a free, open-source AI gateway that provides a single OpenAI-compatible endpoint for 268+ LLM providers with auto-fallback, quota management, and token compression.

## Installation

```bash
npm install -g omniroute
```

## Public Access Setup

**Critical:** OmniRoute binds to localhost by default. To expose on all interfaces:

```bash
# Set environment variable before starting
export OMNIROUTE_SERVER_HOST=0.0.0.0

# Start server
omniroute serve --port 20128 --no-open
```

Or use systemd with the environment variable in the service file.

## systemd Service

```ini
[Unit]
Description=OmniRoute AI Gateway
After=network.target

[Service]
Type=simple
User=root
Environment=OMNIROUTE_SERVER_HOST=0.0.0.0
Environment=OMNIROUTE_PORT=20128
ExecStart=/usr/local/bin/omniroute serve --port 20128 --no-open
Restart=always
RestartSec=30

[Install]
WantedBy=multi-user.target
```

## Usage

### Dashboard
Open in browser: `http://SERVER_IP:20128`

### API Endpoint
```
http://SERVER_IP:20128/v1
```

### List Models
```bash
curl http://SERVER_IP:20128/v1/models
```

### Use with IDE Tools
Set in your tool's configuration:
```
OPENAI_BASE_URL=http://SERVER_IP:20128/v1
OPENAI_API_KEY=any_string
```

## Features
- 268 providers, one endpoint
- 90+ free providers
- Auto-fallback between providers
- Token compression (RTK + Caveman, 15-95% savings)
- Built-in MCP server (104 tools)
- Memory (FTS5 + vector recall)
- Dashboard with Next.js

## Pitfalls

### Port Already in Use
If starting via systemd fails with `EADDRINUSE`:
```bash
# Kill existing process
pkill -f omniroute
sleep 2
# Restart service
systemctl restart omniroute
```

### Slow npm Install
First install can take 4-5 minutes due to many dependencies. Use `background=true` for the install command.

## Management
```bash
systemctl status omniroute
systemctl restart omniroute
journalctl -u omniroute -f
```
