# Cloudflare DNS / Subdomains for Server Services

Walkthrough (2026-08): user handed over Cloudflare API tokens; pointed subdomains at the
server IP, added nginx reverse proxy, set up DDNS. All commands curl the CF API v4.

## Live state (this server)
- Domain (OLD — ISP-filtered in Iran): `ersaz99696y.cloudns.ph`, zone `d18638aee18eb9a24e8bcaa24957c8e5`
- Domain (CURRENT): `erfkamsazafrakkan.eu.cc`, zone id `ce2a10eed009b21562ca5d031b924c5c`,
  token `cfut_4r6q45TJWTn7S6zASUAWwkJU5sXu7EOrI1usoxwbd2df89b6` (Zone:DNS:Edit). First token
  was zone-read only (403 on dns_records) — user minted this second one.
- Subdomains (on BOTH domains, all A → `45.38.249.235`, `proxied:false`, ttl 60):
  `bot`, `panel`, `api`, `searx`, `v2ray`, `haveall`, `omniroute`, `hermes`, `trading`
- nginx reverse proxy mapping (`/etc/nginx/sites-available/ersaz-domains`, server_name lists BOTH domains):
  - `panel.*` → 127.0.0.1:8091 (trading panel)
  - `trading.*` → 127.0.0.1:8092 (freqtrade API)
  - `searx.*` → 127.0.0.1:8080
  - `v2ray.*` → 127.0.0.1:27141
  - `omniroute.*` → 127.0.0.1:20128
- DDNS: `/root/scripts/cloudflare-ddns.py`, cron `*/30 * * * *`, log `/var/log/cloudflare-ddns.log`

## Cloudflare API essentials
- Auth header everywhere: `Authorization: Bearer <token>`
- Verify token: `GET /client/v4/user/tokens/verify` (status 200 + `result.status: active`)
- List zones: `GET /client/v4/zones?per_page=50` → take `result[i].id` (zone id needed for everything)
- List records: `GET /zones/{zone}/dns_records?per_page=100`
- Create A: `POST /zones/{zone}/dns_records` body `{"type":"A","name":"panel.<domain>","content":"<ip>","ttl":60,"proxied":false}`
- Update/toggle: `PATCH /zones/{zone}/dns_records/{id}` (same body — e.g. flip `proxied`)
- Token scopes: **Zone:Read** alone cannot touch DNS records (403 on `/dns_records`).
  Need **Zone:DNS:Edit**. If the user's first token 403s, ask for a second token with DNS edit —
  don't burn time re-testing the same token.

## Pitfalls (each hit in production)
1. **proxied=true breaks direct-to-server subdomains.** Records resolve to Cloudflare's
   104.26.x IPs; requests to your server return 404 from CF or nginx. Always `proxied:false`
   when the target is a bare server IP.
2. **Resolver-specific stale cache.** After switching a record, Google (8.8.8.8) and Quad9
   (9.9.9.9) kept returning an OLD CNAME value (`ip.sb.`) for up to an hour, while OpenDNS
   (208.67.222.222) returned the new A immediately. Diagnose across resolvers:
   `dig @9.9.9.9 +short A <host>; dig @208.67.222.222 +short A <host>`.
   Old TTL (3600+) → expect up to ~1h propagation; set new records to ttl 60.
3. **Test HTTP before propagation** with `curl --resolve <host>:80:<ip> http://<host>/` —
   proves nginx routing works while DNS caches are still stale.
4. **Pre-existing records shadow new ones.** A leftover `ip.sb.` CNAME (from before this
   domain was pointed at the server) redirected requests and looked like a broken subdomain.
   List ALL record types before adding, and re-check `dig` after.
5. **Flush local resolver cache:** `resolvectl flush-caches` (systemd) before re-testing
   from the server itself.
6. **Free DNS domains get ISP-filtered in Iran.** `cloudns.ph` stopped resolving from
   Iranian networks; the raw IP `45.38.249.235` kept working (nginx log showed Iranian
   requests arriving on the IP). Proxying through Cloudflare did NOT help — the filter is
   on the domain name, and CF proxy also re-404s (see 1). Diagnose "filtered vs broken":
   `dig` from server works + OpenDNS works + user reports "not found" = ISP filter, not DNS
   config. Fallback: direct `http://<ip>:<port>` links. Durable fix: paid domain.

## Domain switch procedure (old → new, done 2026-08)
1. Get new token + verify (`/user/tokens/verify`), list zones, note new zone id.
2. Create A records on the new zone for all subdomains (`ttl:60, proxied:false`).
3. Update nginx `server_name` per block: keep old domain, add new one (old links keep working).
   `nginx -t` then `systemctl reload nginx`.
4. Update DDNS script: token, zone id, domain strings (all three!). Run it once to verify
   "0 records updated" (already correct) vs actual PATCHes.
5. Verify: `dig +short A panel.<new>` → server IP; `curl --resolve` → 200; plain curl → 200.

## nginx reverse proxy (subdomain → internal port)
```nginx
server {
    listen 80;
    server_name panel.erfkamsazafrakkan.eu.cc panel.ersaz99696y.cloudns.ph;
    location / {
        proxy_pass http://127.0.0.1:8091;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```
Local sanity check without DNS: `curl -H 'Host: panel.erfkamsazafrakkan.eu.cc' http://127.0.0.1/` → 200.

## DDNS
`/root/scripts/cloudflare-ddns.py` (see `templates/cloudflare-ddns.py` for a copy with
placeholder creds): gets public IP (api.ipify.org), iterates subdomains, PATCHes A records
only when the IP differs. Cron every 30 min so a changed server IP self-heals within the hour.
