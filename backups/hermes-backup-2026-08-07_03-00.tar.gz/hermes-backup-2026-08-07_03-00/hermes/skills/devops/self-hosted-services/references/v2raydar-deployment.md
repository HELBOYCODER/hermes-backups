# V2RayDAR Deployment Reference

## What It Is

V2RayDAR is a Rust CLI/TUI that fetches V2Ray/Clash/Mihomo subscription sources, validates configs through sing-box, ranks working ones, and re-publishes at a local subscription URL.

## Installation

### Via install script (recommended)
```bash
# Portable mode (everything in one folder)
NON_INTERACTIVE=1 sh install.sh --portable

# User mode (binary to ~/.local/bin)
NON_INTERACTIVE=1 sh install.sh --user
```

### Manual from release
Download from https://github.com/411A/V2RayDAR/releases/latest, extract, and run.

## systemd Service

```ini
[Unit]
Description=V2RayDAR - V2Ray Detection And Reconnaissance
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/V2RayDAR
ExecStart=/root/V2RayDAR/v2raydar --no-tui --portable
Restart=always
RestartSec=30
Environment=HOME=/root

[Install]
WantedBy=multi-user.target
```

## Configuration

Config file: `configs.yaml` in the install directory. Key settings:
- `bind: 127.0.0.1:27141` — local subscription endpoint
- `top_n: 10` — number of best configs to publish
- `refresh_seconds: 300` — auto-refresh interval
- `proxy.enabled: true` — persistent local SOCKS5/HTTP proxy on port 27910

## Endpoints

| Endpoint | Format | Use For |
|----------|--------|---------|
| `/subscription` | Base64 V2Ray share-links | v2rayN, v2rayNG |
| `/mihomo.yaml` | Full Mihomo YAML config | Clash Verge, Mihomo |

## Pitfalls

### `--no-tui` flag required for headless/server
Without TUI, the binary tries to open a terminal UI which fails on servers. Always use `--no-tui` in systemd or headless environments.

### sing-box binary must be in same directory
The installer bundles sing-box. If manually installing, ensure sing-box is in the same directory as v2raydar.

### Some subscription sources fail
This is normal — V2RayDAR reports fetch errors per source and continues with working ones. Don't treat fetch failures as installation problems.

## Verification

```bash
# Check service status
systemctl status v2raydar

# Check logs
journalctl -u v2raydar -f

# Test subscription endpoint
curl -s http://127.0.0.1:27141/subscription | base64 -d | head -5

# Check ranked results in logs
journalctl -u v2raydar --no-pager | grep "rank.*proto.*name"
```

## Integration with Hermes

V2RayDAR can provide proxy connectivity for the server. When `proxy.enabled: true`, apps can use `127.0.0.1:27910` as a SOCKS5/HTTP proxy.
