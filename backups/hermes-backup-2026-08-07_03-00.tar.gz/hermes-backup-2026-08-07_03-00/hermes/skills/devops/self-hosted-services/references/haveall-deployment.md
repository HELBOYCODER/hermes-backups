# HaveAll Deployment Reference

## What It Is

HaveAll (همه برای تو) is a multi-source VPN config scraper and Telegram bot. It:
- Scrapes V2Ray/Clash/Mihomo subscription sources
- Collects MTProto Telegram proxies
- Provides a Telegram bot for config distribution
- Requires Supabase for data storage

## Prerequisites

1. **Telegram Bot Token** - from @BotFather
2. **Admin Telegram ID** - your user ID (use @UserInfoBot)
3. **Supabase project** - with URL and API key

## Installation

```bash
cd /opt
git clone https://github.com/v3ndettaaa/HaveAll.git
cd HaveAll/telegram_bot
```

### Environment Setup

Create `.env` file:
```bash
BOT_TOKEN=your_bot_token_from_botfather
ADMIN_IDS=your_telegram_id
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your_supabase_key
```

## Critical: Supabase Key Compatibility

**The old Python `supabase` library does NOT work with new key formats (`sb_publishable_`, `sb_secret_`).**

See `references/supabase-key-format-pitfall.md` for the workaround (custom REST client).

### Fix Applied

Replace the import in `scrapper.py` and `telegram_bot.py`:
```python
# OLD (broken with new keys):
from supabase import create_client, Client

# NEW (works with sb_secret_ keys):
from supabase_rest import create_client, SupabaseRESTClient as Client
```

Remove `supabase` from `requirements.txt` (httpx is already included).

## Docker Deployment

```bash
# Build
docker build -t haveall_bot .

# Run
docker run -d \
  --name haveall_telegram_bot \
  --restart unless-stopped \
  --env-file /opt/HaveAll/telegram_bot/.env \
  haveall_bot:latest
```

## Supabase Database Setup

Run the SQL setup script in Supabase SQL Editor:
- File: `telegram_bot/setup_supabase.sql`
- Creates tables: `monitored_channels`, `proxies`, `configs`, `bot_users`, `settings`, `subscriptions`
- Seeds default channels and subscription links

## Bot Commands

### User Commands
- `/start` - Open main menu
- `/replaceip` - Replace server IPs in VPN configs
- `/cancel` - Cancel current operation

### Admin Commands
- `/scrape` - Trigger manual sync
- `/addchannel [username]` - Add Telegram proxy channel
- `/removechannel [username]` - Remove channel
- `/addsub [url] [remarks]` - Add subscription URL
- `/removesub [id]` - Remove subscription

## Verification

```bash
# Check container is running
docker ps | grep haveall

# Check logs
docker logs haveall_telegram_bot --tail 20

# Look for successful startup
# Should see: "🤖 HaveAll Telegram Bot running successfully"
```

## Common Errors

1. **`Invalid API key`** - Supabase key format issue (see above)
2. **`401 Unauthorized`** - Invalid Telegram bot token
3. **`ModuleNotFoundError`** - Missing supabase_rest.py (ensure it's copied to container)

## Management

```bash
# Restart
docker restart haveall_telegram_bot

# Stop
docker stop haveall_telegram_bot

# View logs
docker logs -f haveall_telegram_bot

# Rebuild after code changes
cd /opt/HaveAll/telegram_bot
docker build -t haveall_bot .
docker stop haveall_telegram_bot && docker rm haveall_telegram_bot
docker run -d --name haveall_telegram_bot --restart unless-stopped --env-file .env haveall_bot:latest
```
