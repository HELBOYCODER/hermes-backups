# Disk Maintenance & Bloat Recovery (Ubuntu server)

Scenario that produced this: disk usage jumped 8GB → 24GB after installing txtai
(torch + CUDA wheels). GPU-less server (2 vCPU, 3.8GB RAM). This reference covers
the recovery and the ongoing maintenance setup.

## Diagnose bloat

```bash
df -h / | tail -1
du -sh /root/* /opt/* /var/lib/docker /var/cache/apt /usr/local/lib/node_modules 2>/dev/null | sort -rh | head -20
docker images --format "{{.Repository}}:{{.Tag}} {{.Size}}"
```

Suspects in order: pip cache (was 3GB), CUDA/nvidia packages, node_modules
(3.5GB for omniroute etc.), apt cache, docker images (old replaced images like
`telegram_bot-bot` vs `haveall_bot`), journal logs, graphify caches
(`/root/graphify-*/graphify-out/cache`).

## Safe cleanup (caches only — no package removal)

```bash
pip3 cache purge                      # freed ~3GB in the incident
apt-get clean && apt-get autoremove -y
npm cache clean --force
docker system prune -f
journalctl --vacuum-time=3d
find /tmp -type f -mtime +1 -delete
ls -t /root/backups/hermes-backup-*.tar.gz | tail -n +6 | xargs rm -f   # keep last 5
```

## The torch/CUDA trap (GPU-less servers)

`pip install txtai` (or any torch-dependent ML lib) resolves the CUDA build by
default: torch + nvidia-* packages ≈ 2.7GB dead weight on a box with no GPU.

**Correct install order:**

```bash
pip3 install --break-system-packages torch --index-url https://download.pytorch.org/whl/cpu
pip3 install --break-system-packages txtai
```

**Recovery when CUDA packages were already removed and torch broke:**

Deleting `triton` (a CUDA dep) removes torch's runtime too — symptom:
`ImportError: Torch is not installed` from txtai even though torch shows as
installed. Fix: reinstall CPU torch (command above). Verified working:
`torch-2.13.0+cpu`, txtai re-imports and `Embeddings.search()` works.

Also check: the box may have had `nvidia-smi`-less CUDA toolkits (`pip list | grep -i nvidia`)
— uninstall those with `pip3 uninstall --break-system-packages -y <pkg>`.

## Automated maintenance

`/root/scripts/disk-cleanup.sh` on cron every 6h (Hermes cron job, not system cron):

- Runs all safe cleanups above, logs to `/root/scripts/disk-cleanup.log`
- Threshold tier: if free space < 20GB, also removes graphify caches and old temp files
- Reports `Disk: XGB → YGB free`

Always verify ML services still import after cleanup: caches are safe to purge,
packages are not. If a cleanup run breaks torch, use the CPU-index reinstall above.
