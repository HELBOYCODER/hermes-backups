# Cron no_agent Watchdogs — failure → fix walkthrough (Aug 2026)

## Symptom
User reported V2RayDAR servers not updating. Investigation showed ALL cron jobs failing with `last_status: error`:
- V2RayDAR Monitor (every 10m)
- HaveAll Bot Monitor (every 15m)
- Hermes FA Docs Watchdog (every 15m)
- Daily Backup (0 3 * * *)
- Disk Cleanup (every 360m)

Services themselves were fine — the scheduler had stopped executing them.

## Root cause
The routed model for cron jobs had changed (deepseek → gemini) and jobs were not pinned. Hermes pauses unpinned LLM-driven jobs when the model config changes, to prevent unwanted spend. Every run then reports `last_status: error`. Nothing wrong with the services.

## Fix — convert all monitors to no_agent script jobs

1. Copy scripts into `~/.hermes/scripts/` (the cronjob tool rejects absolute/home-relative paths):
```bash
cp /root/V2RayDAR/scripts/monitor.sh      ~/.hermes/scripts/v2raydar-monitor.sh
cp /root/scripts/haveall-monitor.sh       ~/.hermes/scripts/haveall-monitor.sh
cp /root/scripts/hermes-fa-watchdog.sh    ~/.hermes/scripts/hermes-fa-watchdog.sh
cp /root/scripts/backup.sh                ~/.hermes/scripts/backup.sh
cp /root/scripts/disk-cleanup.sh          ~/.hermes/scripts/disk-cleanup.sh
chmod +x ~/.hermes/scripts/*.sh
```
2. Update each job: `cronjob action=update`, `no_agent=true`, `script=<bare-filename>`.
3. Test each: `cronjob action=run job_id=<id>` → confirm `execution_success: true`, `last_status: ok`.

## Result
- All five jobs green again, zero LLM tokens consumed (no model involved at all).
- V2RayDAR monitor immediately detected the pending config change and restarted the service.
- Watchdog semantics in no_agent mode: empty stdout = silent (no message); non-zero exit = error alert; stdout is delivered verbatim.

## Rule of thumb
A job that only checks `systemctl is-active`, `curl`, hash-compare, or tar-rotate **never needs a model** — create it as no_agent from day one. Reserve LLM cron jobs for jobs that genuinely need reasoning (daily digests, feed summaries). This also makes the job immune to model/provider config changes and pinning issues.
