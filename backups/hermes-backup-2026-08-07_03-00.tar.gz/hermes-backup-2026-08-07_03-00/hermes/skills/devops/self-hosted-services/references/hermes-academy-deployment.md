# Hermes Academy Deployment (Rust CLI)

Converts Hermes work into structured, searchable lessons. Zero-dependency Rust CLI.
Repo cloned at `/opt/hermes-academy` on user's server.

## Install

```bash
git clone <repo> /opt/hermes-academy
cd /opt/hermes-academy
cargo build --release
cp target/release/hermes-academy /usr/local/bin/
```

## Pitfall: apt cargo cannot parse Cargo.lock v4

Ubuntu 24.04's `apt install rustc cargo` gives cargo 1.75, which fails with:

```
error: failed to parse lock file at: Cargo.lock
Caused by:
  lock file version 4 requires `-Znext-lockfile-bump`
```

Fix: install modern toolchain via rustup (minimal profile is enough), then source env:

```bash
curl -fsSL https://sh.rustup.rs | sh -s -- -y --profile minimal
source ~/.cargo/env   # cargo 1.97+ — needed in every new shell
cargo build --release
```

Do NOT bother pinning the lockfile down — rustup is the standard fix.

## Lesson storage layout

```
~/.hermes/academy/
├─ <Category>/            # DevOps, Linux, Rust, Cargo, Git, Networking, ...
│  └─ YYYYMMDD-<slug>.md
└─ _meta/
   ├─ progress.txt
   └─ <category>/_index.txt
```

## Lesson file format (exact)

Header block then `# Section` markdown body. Reproduce this exactly — the CLI's
`list`/`search`/`dashboard` parse the header fields:

```markdown
<!-- HERMES ACADEMY LESSON -->
ID: <slug>-YYYYMMDD
Title: <one line>
Category: <DevOps|Linux|Rust|Cargo|Git|Networking|Docker|Security|DevOps|AI|Architecture|Performance|UI|Backend|Frontend|Database>
Difficulty: <Beginner|Intermediate|Advanced>
Created: <unix ts>
TimeSavedMin: <float>
HermesSec: <float>
Summary: <one line>
Concepts: <comma separated>
Related: <comma separated>

---

# Summary
# Problem
# Investigation
# Solution
# Technical Explanation
# Why This Works
# Professional Best Practices
# Common Mistakes
# Alternative Solutions
# Commands Used
```bash
...
```
# Files Modified
- <path>
# Before vs After
Before:
```
...
```
After:
```
...
```
# Key Concepts Learned
✔ Concept
# Difficulty
# Time Saved
Estimated manual debugging time: X minutes
Hermes solved it in: Y seconds
# Related Topics
# References
- <url>
# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated
# Quiz
1. <question>
```

## CLI commands

```bash
hermes-academy list [category]     # list lessons (newest first)
hermes-academy search "<query>"    # rg-based full-text search
hermes-academy show <id-or-path>   # display lesson (bat if installed)
hermes-academy dashboard|stats     # progress dashboard
hermes-academy random              # random review lesson
```

## Notes

- No systemd service needed — it's a CLI, invoked on demand.
- Sample lesson created from the OmniRoute deployment: `~/.hermes/academy/DevOps/20260805-omniroute.md`.
- The repo's README shows a `hermes-academy-gen` CLI variant; the installed binary
  here only has the `list/search/show/dashboard/random` commands (no generator).
