# Browser Automation / Chrome DevTools MCP (verified working)

## Problem
`chrome-devtools-mcp` (official Google MCP, ~48K stars) launches Chrome itself; on this
server the `chromium` snap fails inside MCP with `Target closed` — AppArmor/sandbox kills
the spawned browser even when `--no-sandbox` is passed through the MCP args. apt's
`chromium-browser` is only a transitional wrapper that errors "requires the chromium snap
to be installed".

## Fix: Playwright's bundled Chromium
```bash
pip3 install --break-system-packages playwright
python3 -m playwright install chromium --with-deps
```
Installs to `/root/.cache/ms-playwright/chromium-<ver>/chrome-linux64/chrome`
(plus `chromium_headless_shell-<ver>`). The version dir changes per playwright release —
always rediscover, never hardcode:
```bash
find /root/.cache/ms-playwright -name chrome -path "*chrome-linux64*"
```

## Verify browser standalone BEFORE touching MCP
```bash
timeout 15 /root/.cache/ms-playwright/chromium-<ver>/chrome-linux64/chrome \
  --headless --no-sandbox --disable-dev-shm-usage --dump-dom https://example.com
# expect: <title>Example Domain</title>
```

## Hermes config (`~/.hermes/config.yaml`)
```yaml
mcp_servers:
  chrome-devtools:
    command: chrome-devtools-mcp
    args:
      - --headless
      - --isolated
      - --executablePath
      - /root/.cache/ms-playwright/chromium-<ver>/chrome-linux64/chrome
      - --no-sandbox
      - --disable-dev-shm-usage
      - --no-performance-crux
      - --no-usage-statistics
```
Editing the YAML via python yaml.safe_load/safe_dump rewrites formatting but preserves
function. MCP servers load at gateway start → user must run
`systemctl restart hermes-gateway.service` externally (in-session restart is guard-blocked,
see `hermes-gateway-ops.md`). Tools surface in the session as `mcp__chrome_devtools__*`.

## Standalone MCP smoke test (without full gateway restart)
Launch the binary briefly and confirm it boots (prints the "exposes content of the browser
instance" banner) and exits cleanly on timeout:
```bash
timeout 15 chrome-devtools-mcp --headless --isolated \
  --executablePath /root/.cache/ms-playwright/chromium-<ver>/chrome-linux64/chrome \
  --no-sandbox --disable-dev-shm-usage
```
JSON-RPC-over-stdio piping (`printf '{init}' '{tools/call}' | chrome-devtools-mcp ...`)
hangs on keep-alive and is NOT a reliable smoke test — prefer the banner test, then a real
in-session `navigate_page` after restart.

## Related tools on this server
- `browser-use` (Python, 0.13.7) — agent-driven browsing; reuses the same Playwright
  Chromium install; verify with `python3 -c "import browser_use"`.
- `agent-browser` (Vercel, Rust CLI) — installed via `cargo install`; slow to compile
  (minutes), don't block on it.
