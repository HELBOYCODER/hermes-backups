# Supabase Key Format Pitfall

## Problem

Supabase has introduced new API key formats:
- `sb_publishable_...` (replaces old `anon` key)
- `sb_secret_...` (replaces old `service_role` key)

The Python `supabase` library (v2.x) does NOT recognize these new key formats and raises:
```
supabase._sync.client.SupabaseException: Invalid API key
```

## Affected Libraries

- `supabase` Python library (v2.5.0 and likely earlier)
- Any library expecting the old JWT-format keys (`eyJhbG...`)

## Workaround: REST API Direct Access

The new keys work perfectly with Supabase's REST API (PostgREST). Create a wrapper:

```python
import httpx

class SupabaseRESTClient:
    def __init__(self, url: str, key: str):
        self.url = url.rstrip('/')
        self.key = key
        self.rest_url = f"{self.url}/rest/v1"
        self.headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json"
        }
    
    def table(self, table_name: str):
        return TableQuery(self.rest_url, self.headers, table_name)

class TableQuery:
    def __init__(self, rest_url, headers, table_name):
        self.rest_url = rest_url
        self.headers = headers
        self.table_name = table_name
        self._filters = []
        self._select = "*"
        self._method = "GET"
        self._body = None
    
    def select(self, *columns):
        self._select = ",".join(columns) if columns else "*"
        return self
    
    def insert(self, data):
        self._method = "POST"
        self._body = [data] if isinstance(data, dict) else data
        return self
    
    def update(self, data):
        self._method = "PATCH"
        self._body = data
        return self
    
    def delete(self):
        self._method = "DELETE"
        return self
    
    def eq(self, column, value):
        self._filters.append((column, "eq", value))
        return self
    
    def neq(self, column, value):
        self._filters.append((column, "neq", value))
        return self
    
    def order(self, column, desc=False):
        self._order = f"{column}.{'desc' if desc else 'asc'}"
        return self
    
    def limit(self, count):
        self._limit = count
        return self
    
    def execute(self):
        params = {}
        headers = dict(self.headers)
        
        if self._method == "GET":
            params["select"] = self._select
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            if hasattr(self, '_order'):
                params["order"] = self._order
            if hasattr(self, '_limit'):
                headers["Range"] = f"0-{self._limit - 1}"
            resp = httpx.get(f"{self.rest_url}/{self.table_name}", headers=headers, params=params)
        elif self._method == "POST":
            headers["Prefer"] = "return=representation"
            resp = httpx.post(f"{self.rest_url}/{self.table_name}", headers=headers, json=self._body)
        elif self._method == "PATCH":
            headers["Prefer"] = "return=representation"
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            resp = httpx.patch(f"{self.rest_url}/{self.table_name}", headers=headers, json=self._body, params=params)
        elif self._method == "DELETE":
            headers["Prefer"] = "return=representation"
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            resp = httpx.delete(f"{self.rest_url}/{self.table_name}", headers=headers, params=params)
        
        resp.raise_for_status()
        class Result:
            def __init__(self, data):
                self.data = data
        return Result(resp.json())

def create_client(url, key):
    return SupabaseRESTClient(url, key)
```

## Verification

Test the key works with REST API:
```bash
curl -s "https://YOUR_PROJECT.supabase.co/rest/v1/" \
  -H "apikey: sb_secret_..." \
  -H "Authorization: Bearer sb_secret_..."
```

If this returns the OpenAPI schema (not an error), the key is valid for REST API use.

## Key Locations in Supabase Dashboard

1. Go to supabase.com/dashboard
2. Select your project
3. Settings → API
4. **Project API keys** section:
   - `sb_publishable_...` = public client key
   - `sb_secret_...` = server-side key (use this for REST API)

Note: The old `anon` and `service_role` JWT keys may still exist in some projects. Check both formats.
