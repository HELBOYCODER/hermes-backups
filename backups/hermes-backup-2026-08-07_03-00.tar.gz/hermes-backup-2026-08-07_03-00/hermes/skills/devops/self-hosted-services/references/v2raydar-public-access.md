# V2RayDAR Public Access & Monitoring

## Making V2RayDAR Accessible from Public IP

### Problem
By default, V2RayDAR binds to `127.0.0.1` (local only). Two changes are required for public access.

### Solution
Edit `v2raydar_data/configs.yaml` (NOT the root `configs.yaml` in `--portable` mode):

```yaml
bind: 0.0.0.0:27141        # Changed from 127.0.0.1
sharing:
  enabled: true             # MUST be true for public access
```

Restart after editing:
```bash
systemctl restart v2raydar
```

### Verify public access
```bash
# Check it's listening on 0.0.0.0
ss -tlnp | grep 27141

# Test from public IP
curl -s -o /dev/null -w "HTTP Status: %{http_code}\n" http://YOUR_PUBLIC_IP:27141/health
```

## Config Change Monitoring

### Script: `/root/V2RayDAR/scripts/monitor.sh`
```bash
#!/bin/bash
V2RAYDAR_URL="http://127.0.0.1:27141/subscription"
HASH_FILE="/root/V2RayDAR/v2raydar_data/last_hash.txt"
LOG_FILE="/root/V2RayDAR/v2raydar_data/monitor.log"

mkdir -p /root/V2RayDAR/v2raydar_data

CURRENT_HASH=$(curl -s "$V2RAYDAR_URL" | md5sum | awk '{print $1}')

if [ ! -f "$HASH_FILE" ]; then
    echo "$CURRENT_HASH" > "$HASH_FILE"
    echo "[$(date)] First run - hash saved: $CURRENT_HASH" >> "$LOG_FILE"
    exit 0
fi

SAVED_HASH=$(cat "$HASH_FILE")
if [ "$CURRENT_HASH" != "$SAVED_HASH" ]; then
    echo "[$(date)] Configs changed! Refreshing..." >> "$LOG_FILE"
    echo "$CURRENT_HASH" > "$HASH_FILE"
    systemctl restart v2raydar
    echo "[$(date)] Service restarted" >> "$LOG_FILE"
else
    echo "[$(date)] No changes detected" >> "$LOG_FILE"
fi
```

### Cron job setup
```
*/10 * * * * /root/V2RayDAR/scripts/monitor.sh
```

## KNOWN BEHAVIOR: monitor reports "Configs changed!" on nearly every run

**Observed (Aug 2026):** every entry in `monitor.log` since the first run says
`Configs changed!` + `Service restarted` — `No changes detected` never appears.
This is EXPECTED, not a malfunction.

**Root cause:** V2RayDAR re-fetches and re-ranks its source subscriptions every
`refresh_seconds: 300` (5 min, set in `configs.yaml`). The published `/subscription`
content is therefore regenerated continuously — configs get added/dropped/reordered —
even when the on-disk `configs.yaml` file is untouched (its mtime stays stable).
The monitor's hash-compare on the live endpoint thus sees a diff on almost every cycle,
and the service gets restarted every ~11–16 min.

**Implications:**
- Restarting the service every monitor cycle is wasteful and can interrupt active
  connections; the subscription content is served dynamically, so a restart is NOT
  required to pick up new configs.
- To detect *real* config changes instead, compare `configs.yaml` mtime or content
  (which is what actually controls what V2RayDAR publishes), not the live hash.

### How to diagnose (if monitor behavior looks wrong)
```bash
# 1. Check the monitor log — silent script, all output goes here
tail -20 /root/V2RayDAR/v2raydar_data/monitor.log

# 2. Trace the script to see what it actually does
bash -x /root/V2RayDAR/scripts/monitor.sh

# 3. Back-to-back fetches: identical within seconds, different across minutes
curl -s http://127.0.0.1:27141/subscription | md5sum

# 4. Decode + diff the actual config lists to see what changed
curl -s http://127.0.0.1:27141/subscription | base64 -d > /tmp/sub1.dec
sleep 60
curl -s http://127.0.0.1:27141/subscription | base64 -d > /tmp/sub2.dec
diff /tmp/sub1.dec /tmp/sub2.dec

# 5. Confirm the refresh interval that drives the churn
grep refresh_seconds /root/V2RayDAR/v2raydar_data/configs.yaml
```

## systemd Service

```ini
[Unit]
Description=V2RayDAR - V2Ray Detection And Reconnaissance
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/V2RayDAR
ExecStart=/root/V2RayDAR/v2raydar --no-tui --portable
Restart=always
RestartSec=30
Environment=HOME=/root

[Install]
WantedBy=multi-user.target
```

## Quick Reference

| Endpoint | Format | URL |
|----------|--------|-----|
| Subscription (base64) | V2Ray share-links | `http://IP:27141/subscription` |
| Mihomo YAML | Clash/Mihomo config | `http://IP:27141/mihomo.yaml` |
| Plain text | sing-box compatible | `http://IP:27141/subscription.txt` |
| Health check | Status check | `http://IP:27141/health` |
