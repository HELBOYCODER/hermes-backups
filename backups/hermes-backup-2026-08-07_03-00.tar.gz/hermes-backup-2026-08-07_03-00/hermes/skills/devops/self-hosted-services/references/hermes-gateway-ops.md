# Hermes Gateway Ops

Operational notes for the Hermes gateway on this server (systemd unit `hermes-gateway.service`, process visible via `ps aux | grep "hermes gateway"`).

## Gateway restart guard (design constraint)

The gateway refuses to restart itself from inside its own process. Every in-session route is blocked with: "Run `hermes gateway restart` from a separate shell outside the running gateway."

Blocked (all confirmed blocked this session):
- `systemctl restart hermes-gateway.service`
- `hermes gateway restart`
- `systemd-run --on-active=10s systemctl restart hermes-gateway.service`
- `echo "systemctl restart ..." | at now + 1 minute`
- `cronjob` create whose prompt contains a gateway lifecycle command (guard #30719: "prevent agent-driven SIGTERM-respawn loops under launchd/systemd supervision")

Working path:
- A shell NOT spawned by the gateway (user's own terminal, or a pre-gateway-start context) runs: `systemctl restart hermes-gateway.service`

## Browser extension API server

Hermes Browser Extension (repo cloned at `/opt/hermes-browser-extension`; scripts: `build`, `build:firefox`, zero runtime deps) connects to the gateway API at `http://127.0.0.1:8642` by default.

Enable by appending to `~/.hermes/.env`:

```
API_SERVER_ENABLED=true
API_SERVER_HOST=0.0.0.0        # 127.0.0.1 for local-only; 0.0.0.0 only behind trusted proxy/VPN
API_SERVER_PORT=8642
API_SERVER_KEY=<openssl rand -hex 32>
API_SERVER_CORS_ORIGINS=chrome-extension://<extension-id>
```

Notes:
- Requires a gateway restart to take effect → user must run it from an external shell (see guard above). Until then the port is not listening.
- Extension ID appears only after loading unpacked in `chrome://extensions` — set `API_SERVER_CORS_ORIGINS` to the real ID, then restart again.
- Verify: `ss -tlnp | grep 8642`, then `curl http://127.0.0.1:8642/...` from the host.
- Do not expose a keyed API naked to the internet (README warning) — LAN/VPN or HTTPS reverse proxy only.
- README modes: Local API server (key via `API_SERVER_KEY`), Remote API server (explicit URL + token), Hermes Cloud (signed-in HTTPS agent tab).
