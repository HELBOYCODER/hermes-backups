# SearXNG Deployment Reference

## Docker Setup

```bash
docker run -d --name searxng \
  -p 8080:8080 \
  -v /opt/searxng/settings.yml:/etc/searxng/settings.yml \
  -v /opt/searxng/limiter.toml:/etc/searxng/limiter.toml \
  -e SEARXNG_BASE_URL=http://localhost:8080/ \
  --restart unless-stopped \
  searxng/searxng:latest
```

## Configuration Pitfalls

### 1. `default_doi_resolver` is REQUIRED
The latest SearXNG versions crash with `KeyError: 'default_doi_resolver'` if this setting is missing. Add to `settings.yml`:

```yaml
doi_resolvers:
  oadoi.org: 'https://oadoi.org/'
  doi.org: 'https://doi.org/'
  dx.doi.org: 'https://dx.doi.org/'
  doai.io: 'https://doai.io/'
  worldcat.org: 'https://www.worldcat.org/'
  libgen.gs: 'https://libgen.gs/'

default_doi_resolver: 'oadoi.org'
```

### 2. Locale validation
`default_locale: "fa"` (Farsi) is NOT supported and causes `ValidationException`. Use `"auto"` or `"en"`:
```yaml
ui:
  default_locale: "en"  # NOT "fa"
search:
  default_lang: "auto"  # Language detection, not locale
```

### 3. Engine names cannot contain underscores
```yaml
# WRONG - causes "Engine name contains underscore" error
- name: docker_hub
- name: grep_app

# RIGHT - use the engine module name
- name: docker hub
- name: grep.com
```

### 4. Invalid engines cause silent failures
Some engines in the default config may not exist in the Docker image version. Start with minimal engines:
```yaml
engines:
  - name: google
    engine: google
  - name: duckduckgo
    engine: duckduckgo
  - name: bing
    engine: bing
  - name: wikipedia
    engine: wikipedia
  - name: github
    engine: github
  - name: arxiv
    engine: arxiv
  - name: npm
    engine: npm
  - name: pypi
    engine: pypi
```

### 5. Limiter requires Valkey (not Redis)
The SearXNG limiter now requires Valkey, not Redis. Either:
- Install Valkey, OR
- Disable the limiter: `limiter: false` in settings.yml
- Remove the `limiter.toml` volume mount if disabling

### 6. Minimal working settings.yml
```yaml
general:
  instance_name: "SearXNG"
  debug: false

search:
  safe_search: 0
  autocomplete: "google"
  default_lang: "auto"
  formats:
    - html
    - json

server:
  port: 8080
  bind_address: "0.0.0.0"
  secret_key: "<random-hex-32>"
  image_proxy: true
  limiter: false

ui:
  static_use_hash: true
  default_theme: simple

outgoing:
  request_timeout: 5.0

doi_resolvers:
  oadoi.org: 'https://oadoi.org/'
  doi.org: 'https://doi.org/'

default_doi_resolver: 'oadoi.org'
```

## Verification

```bash
# Check container is running
docker ps | grep searxng

# Check logs for errors
docker logs searxng --tail 20

# Test HTTP endpoint
curl -s -o /dev/null -w "HTTP Status: %{http_code}\n" http://localhost:8080/

# Test search API
curl -s "http://localhost:8080/search?q=test&format=json" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Results: {len(d.get(\"results\",[]))}')"
```

## Debugging 500 Errors

1. Check logs: `docker logs searxng 2>&1 | grep -i error`
2. Common errors:
   - `KeyError: 'default_doi_resolver'` → add doi_resolvers config
   - `Invalid value: "fa"` → change default_locale to "en"
   - `Engine name contains underscore` → fix engine names
   - `X-Forwarded-For nor X-Real-IP header is set` → expected when accessing directly (not behind proxy)
3. Test with minimal config first, then add features
