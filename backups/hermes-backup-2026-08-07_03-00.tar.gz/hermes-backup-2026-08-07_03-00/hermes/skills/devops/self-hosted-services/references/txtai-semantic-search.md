# txtai Semantic Search + RAG

Install and quick-test of txtai (Python AI platform: embeddings, FAISS vector search, RAG retrieval, agent workflows) on Ubuntu 24.04 / Python 3.12 / 3.8 GB RAM server.

## Install

```bash
pip3 install --break-system-packages txtai   # pulls torch + faiss-cpu + transformers (~1-2 GB)
```

PEP 668 managed env → `--break-system-packages` (or use a venv).

## Verify & test — there is NO `__version__`

`txtai.__version__` raises `AttributeError: module 'txtai' has no attribute '__version__'`.
There is also no CLI entrypoint (`python3 -m txtai` → "No module named txtai.__main__"). Test by importing the real API:

```python
from txtai.embeddings import Embeddings

data = ["doc one", "doc two", "..."]
emb = Embeddings(content=True, path="sentence-transformers/all-MiniLM-L6-v2")
emb.index(data)
for r in emb.search("query", 3):
    print(r["text"], r["score"])
```

- `content=True` stores original text alongside vectors so search returns text, not just ids.
- `sentence-transformers/all-MiniLM-L6-v2` is small/fast and right-sized for a 3.8 GB RAM server (first run downloads ~90 MB weights from HF Hub).
- If HF Hub is slow/blocked, expect "unauthenticated requests" warning — harmless, just slower.

## RAG without an LLM

`Extractor(embeddings)` fails:
`TypeError: RAG.__init__() missing 1 required positional argument: 'path'`
— txtai's RAG/Extractor pipeline requires an LLM model path. For retrieval-only RAG (context lookup without generation), skip Extractor and use search directly:

```python
context = " | ".join(r["text"] for r in emb.search(q, 2))
```

## Demo layout

`/opt/txtai-demo/demo.py` — three working demos: semantic search, RAG retrieval, agent workflow orchestration. Run: `python3 /opt/txtai-demo/demo.py` (first run downloads the embedding model).
