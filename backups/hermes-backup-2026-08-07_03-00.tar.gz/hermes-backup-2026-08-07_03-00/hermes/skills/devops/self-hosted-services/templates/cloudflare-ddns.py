#!/usr/bin/env python3
"""Cloudflare DDNS — keeps subdomain A records pointed at a server's current IP.

Copy and fill in TOKEN / ZONE_ID / DOMAIN / SUBDOMAINS, then cron it:
    */30 * * * * /path/to/cloudflare-ddns.py >> /var/log/cloudflare-ddns.log 2>&1

Token must have Zone:DNS:Edit scope (a zone-only token 403s on /dns_records).
"""
import json
import sys
import urllib.request

TOKEN = "YOUR_CF_TOKEN"            # cfut_... with Zone:DNS:Edit
ZONE_ID = "YOUR_ZONE_ID"           # from GET /client/v4/zones?name=<domain>
DOMAIN = "example.com"
SUBDOMAINS = ["bot", "panel", "api", "searx", "v2ray", "haveall", "omniroute", "hermes", "trading"]

API = "https://api.cloudflare.com/client/v4"


def get_public_ip():
    for url in ["https://api.ipify.org", "https://ifconfig.me/ip"]:
        try:
            return urllib.request.urlopen(url, timeout=10).read().decode().strip()
        except Exception:
            continue
    return None


def api_request(method, path, data=None):
    req = urllib.request.Request(f"{API}{path}", method=method,
                                 headers={"Authorization": f"Bearer {TOKEN}",
                                          "Content-Type": "application/json"})
    body = json.dumps(data).encode() if data else None
    return json.loads(urllib.request.urlopen(req, body, timeout=30).read())


def sync():
    ip = get_public_ip()
    if not ip:
        print("Could not get public IP")
        return 1
    updated = 0
    for sub in SUBDOMAINS:
        name = f"{sub}.{DOMAIN}"
        recs = api_request("GET", f"/zones/{ZONE_ID}/dns_records?type=A&name={name}")
        for r in (recs.get("result") or []):
            if r["content"] != ip:
                api_request("PATCH", f"/zones/{ZONE_ID}/dns_records/{r['id']}",
                            {"content": ip, "ttl": 60, "proxied": False})
                print(f"updated {name} -> {ip}")
                updated += 1
            else:
                print(f"ok {name} -> {ip}")
    print(f"Done. {updated} records updated.")
    return 0


if __name__ == "__main__":
    sys.exit(sync())
