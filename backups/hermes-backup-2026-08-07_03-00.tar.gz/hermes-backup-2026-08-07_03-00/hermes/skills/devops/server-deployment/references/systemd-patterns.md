# Systemd Service Patterns

## Basic Service Template

```ini
[Unit]
Description=Service Name
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/path/to/app
ExecStart=/path/to/binary
Restart=always
RestartSec=10
Environment=HOME=/root
Environment=PATH=/usr/local/bin:/usr/bin:/bin

# Resource limits
LimitNOFILE=65536
MemoryMax=2G

# Logging
StandardOutput=append:/var/log/svc.log
StandardError=append:/var/log/svc.log

[Install]
WantedBy=multi-user.target
```

## Timer + Service Pattern (for periodic tasks)

```ini
# svc.timer
[Unit]
Description=Run service every hour

[Timer]
OnBootSec=30
OnUnitActiveSec=3600
AccuracySec=5s

[Install]
WantedBy=timers.target
```

```ini
# svc.service (oneshot)
[Unit]
Description=Periodic task

[Service]
Type=oneshot
ExecStart=/path/to/script.sh
```

## Docker + Systemd

```ini
[Unit]
Description=Container Service
After=docker.service
Requires=docker.service

[Service]
Type=simple
Restart=always
RestartSec=30
ExecStartPre=/usr/bin/docker start container-name
ExecStop=/usr/bin/docker stop container-name

[Install]
WantedBy=multi-user.target
```

## Commands

```bash
systemctl daemon-reload          # Reload after changes
systemctl enable svc             # Start on boot
systemctl start svc              # Start now
systemctl status svc             # Check status
systemctl restart svc            # Restart
journalctl -u svc -f             # Follow logs
journalctl -u svc --since "1h ago"  # Recent logs
```

## Pitfalls

- Always `daemon-reload` after editing service files
- Use `Restart=always` for critical services
- Use `RestartSec=10` to prevent rapid restart loops
- Check `journalctl -u svc` when service fails to start
