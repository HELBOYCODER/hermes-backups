# Supabase REST Client

For projects using new `sb_publishable_`/`sb_secret_` key format (2025+), the old `supabase` Python library fails. Use this REST client instead.

## Full Implementation

```python
import httpx
from typing import Any, Dict, List

class QueryResult:
    def __init__(self, data: list):
        self.data = data

class TableQuery:
    def __init__(self, rest_url: str, headers: dict, table_name: str):
        self.rest_url = rest_url
        self.headers = headers
        self.table_name = table_name
        self._filters = []
        self._order = None
        self._limit = None
        self._select = "*"
        self._method = "GET"
        self._body = None
    
    def select(self, *columns):
        self._select = ",".join(columns) if columns else "*"
        return self
    
    def insert(self, data):
        self._method = "POST"
        self._body = [data] if isinstance(data, dict) else data
        return self
    
    def update(self, data):
        self._method = "PATCH"
        self._body = data
        return self
    
    def delete(self):
        self._method = "DELETE"
        return self
    
    def eq(self, column, value):
        self._filters.append((column, "eq", value))
        return self
    
    def neq(self, column, value):
        self._filters.append((column, "neq", value))
        return self
    
    def order(self, column, desc=False):
        self._order = f"{column}.{'desc' if desc else 'asc'}"
        return self
    
    def limit(self, count):
        self._limit = count
        return self
    
    def execute(self):
        params = {}
        headers = dict(self.headers)
        
        if self._method == "GET":
            params["select"] = self._select
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            if self._order:
                params["order"] = self._order
            if self._limit:
                headers["Range"] = f"0-{self._limit - 1}"
            resp = httpx.get(f"{self.rest_url}/{self.table_name}", headers=headers, params=params)
        elif self._method == "POST":
            headers["Prefer"] = "return=representation"
            resp = httpx.post(f"{self.rest_url}/{self.table_name}", headers=headers, json=self._body)
        elif self._method == "PATCH":
            headers["Prefer"] = "return=representation"
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            resp = httpx.patch(f"{self.rest_url}/{self.table_name}", headers=headers, json=self._body, params=params)
        elif self._method == "DELETE":
            headers["Prefer"] = "return=representation"
            for col, op, val in self._filters:
                params[col] = f"{op}.{val}"
            resp = httpx.delete(f"{self.rest_url}/{self.table_name}", headers=headers, params=params)
        
        resp.raise_for_status()
        return QueryResult(resp.json())

class SupabaseREST:
    def __init__(self, url: str, key: str):
        self.url = url.rstrip('/')
        self.rest_url = f"{self.url}/rest/v1"
        self.headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json"
        }
    
    def table(self, table_name: str):
        return TableQuery(self.rest_url, self.headers, table_name)

def create_client(url: str, key: str):
    return SupabaseREST(url, key)
```

## Usage

Replace:
```python
from supabase import create_client, Client
supabase = create_client(url, key)
```

With:
```python
from supabase_rest import create_client, SupabaseREST as Client
supabase = create_client(url, key)
```

The API is compatible with the old library's `.table().select().eq().execute()` pattern.
