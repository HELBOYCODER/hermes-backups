# GitHub Backup Workflow

## Problem
GitHub API has a 1MB file size limit for content uploads. Server backups are typically larger.

## Solution: Git Push
Use `git clone` + `git push` instead of API for large files.

```bash
# Setup
REPO="owner/repo-backups"
export GH_TOKEN="<token>"
cd /tmp
git clone https://${GH_TOKEN}@github.com/${REPO}.git repo-backups
cd repo-backups

# Copy backup
cp /root/backups/backup-*.tar.gz .

# Commit and push
git config user.email "backup@server.local"
git config user.name "Server Backup"
git add .
git commit -m "Backup $(date +%Y-%m-%d_%H-%M)"
git push origin main
```

## Token Requirements
- Token needs `repo` scope for write access
- Classic tokens (`ghp_...`) need full repo scope
- Fine-grained tokens need "Contents: Read and write" permission

## Pitfalls

### Token Can't Create Repos
If token lacks `createRepository` permission:
1. User creates repo manually first
2. Then agent pushes to it

### API Upload Fails with "sha wasn't supplied"
File doesn't exist yet - check if file exists first:
```bash
SHA=$(gh api repos/owner/repo/contents/path/file --jq '.sha' 2>/dev/null)
if [ -z "$SHA" ]; then
    # Create new file
else
    # Update existing (include sha)
fi
```

### Large File Upload via API
Files >1MB fail silently or with cryptic errors. Always use git push for backups.

## Backup Script Template
```bash
#!/bin/bash
set -e
BACKUP_DIR="/root/backups"
DATE=$(date +%Y-%m-%d_%H-%M)
REPO="owner/repo-backups"
export GH_TOKEN=$(grep "^GITHUB_TOKEN=" ~/.hermes/.env | cut -d= -f2)

# Create backup
mkdir -p "${BACKUP_DIR}"
tar -czf "${BACKUP_DIR}/backup-${DATE}.tar.gz" /path/to/configs

# Upload
cd /tmp
git clone https://${GH_TOKEN}@github.com/${REPO}.git 2>/dev/null || true
cd $(basename ${REPO})
cp "${BACKUP_DIR}/backup-${DATE}.tar.gz" .
git add . && git commit -m "Backup ${DATE}" && git push

# Cleanup old local backups (keep 7)
ls -t ${BACKUP_DIR}/backup-*.tar.gz | tail -n +8 | xargs rm -f
```
