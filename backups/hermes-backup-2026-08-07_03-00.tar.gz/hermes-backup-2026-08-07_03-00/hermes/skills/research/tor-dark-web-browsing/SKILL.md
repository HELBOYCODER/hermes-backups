---
name: tor-dark-web-browsing
description: Use when browsing/searching dark web .onion sites via Tor.
---

# Tor / Dark Web Browsing & Search

## When to use
- User asks to browse .onion sites, search the dark web, or route web requests through Tor
- Need anonymous HTTP from the server (SOCKS5 through Tor) — e.g. diagnosing IP-blocked services

## Setup (this server)
- Tor runs as a systemd service: `systemctl enable --now tor` — SOCKS5 proxy at `127.0.0.1:9050`
- Deployed tool: `/opt/darkweb-tool/darkweb.py` — commands: `status`, `search "<query>"`, `browse <url>`
- Core pattern (requests + BeautifulSoup):
```python
session = requests.Session()
session.proxies = {"http": "socks5h://127.0.0.1:9050", "https": "socks5h://127.0.0.1:9050"}
session.headers.update({"User-Agent": "Mozilla/5.0 ... Chrome/126 ..."})
```
- **Must use `socks5h://` (NOT `socks5://`)** — the `h` makes DNS resolve THROUGH Tor; plain socks5 leaks DNS to the local resolver and fails to resolve `.onion` hostnames.

## Search engines (verified via Tor exit IPs)
| Engine | Status | Notes |
|--------|--------|-------|
| DuckDuckGo onion (`duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion`) | ✅ works | Use `/html/?q=...` HTML endpoint; parse `div.result`, `a.result__a` (title), `a.result__snippet` (desc). Returns clearnet links too (wrapped in `/l/?uddg=` redirects) |
| Ahmia (`ahmia.fi`) | ⚠️ empty from Tor exit IPs | HTTP 200 but zero `div.result` elements — serves a challenge/empty page to exit-IP traffic. Don't rely on it; DDG onion is the primary engine |

## Browsing .onion sites
1. `browse <url>`: GET with 45s timeout, strip `script/style/noscript/svg`, extract title + readable text, list all `.onion` hrefs found
2. A specific .onion failing to connect = that SITE is down/offline, not a broken tool. Verify tool health against the known-good DDG onion URL before debugging.
3. Cloudflare-protected pages return `Title: One moment, please...` / "Please wait while your request is being verified" — that's a JS challenge; text extraction gets nothing. Report as blocked, don't retry-loop.

## Verification
- Tor up + exit IP: `GET https://check.torproject.org/api/ip` → `{"IsTor": true, "IP": "..."}`

## Pitfalls
- `.onion` links harvested from pages are frequently dead — verify each before treating as reachable
- Tor exit IP changes per circuit/session; never assume a fixed exit IP (session tokens/cookies bound to exit IP get invalidated on change)
- Aggressive crawling through Tor gets rate-limited fast (both exit nodes and target sites) — keep human pauses between requests

## Files
- `scripts/darkweb.py` — full working CLI (status / search / browse); redeploy to `/opt/darkweb-tool/darkweb.py` if lost
