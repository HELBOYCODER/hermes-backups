#!/usr/bin/env python3
"""
Dark Web Browser & Search Tool — via Tor network.
Commands: status | search "<query>" | browse <url>
Deploy: /opt/darkweb-tool/darkweb.py  (Tor SOCKS5 at 127.0.0.1:9050)
"""
import argparse
import requests
from bs4 import BeautifulSoup

TOR_PROXY = "socks5h://127.0.0.1:9050"  # h = DNS through Tor; socks5:// breaks .onion
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

DDG_ONION = "https://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion"
AHMIA = "https://ahmia.fi"  # NOTE: returns empty result pages to Tor exit IPs (challenge); DDG is primary

session = requests.Session()
session.proxies = {"http": TOR_PROXY, "https": TOR_PROXY}
session.headers.update({"User-Agent": UA})


def check_tor():
    try:
        d = session.get("https://check.torproject.org/api/ip", timeout=15).json()
        return d.get("IsTor", False), d.get("IP", "?")
    except Exception as e:
        return False, str(e)[:60]


def search_ddg(query, limit=10):
    try:
        r = session.get(f"{DDG_ONION}/html/?q={requests.utils.quote(query)}", timeout=30)
        if r.status_code != 200:
            print(f"⚠️ DDG HTTP {r.status_code}")
            return []
        soup = BeautifulSoup(r.text, "html.parser")
        results = []
        for res in soup.select("div.result")[:limit]:
            a = res.select_one("a.result__a")
            snip = res.select_one("a.result__snippet")
            if a:
                results.append({
                    "title": a.get_text(strip=True)[:100],
                    "url": a.get("href", "")[:200],
                    "description": snip.get_text(strip=True)[:300] if snip else "",
                })
        return results
    except Exception as e:
        print(f"⚠️ DDG error: {str(e)[:100]}")
        return []


def browse(url, max_bytes=20000):
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    try:
        r = session.get(url, timeout=45)
        print(f"✅ {r.status_code} | {r.headers.get('content-type','?')[:40]} | {len(r.content)} bytes")
        print(f"📍 URL: {r.url}")
        print("=" * 60)
        soup = BeautifulSoup(r.content[:max_bytes * 4], "html.parser")
        for tag in soup(["script", "style", "noscript", "svg"]):
            tag.decompose()
        title = soup.title.get_text(strip=True) if soup.title else "No title"
        print(f"📄 Title: {title}")
        print("-" * 60)
        lines = [l for l in soup.get_text(separator="\n", strip=True).split("\n") if l.strip()]
        print("\n".join(lines)[:max_bytes])
        print("-" * 60)
        links = sorted(set(a["href"] for a in soup.find_all("a", href=True) if ".onion" in a["href"]))
        if links:
            print(f"🔗 {len(links)} .onion links found:")
            for l in links[:15]:
                print(f"   {l[:150]}")
        return True
    except Exception as e:
        print(f"❌ Error: {str(e)[:150]}")  # often = site offline, not tool broken
        return False


def main():
    p = argparse.ArgumentParser(description="Dark Web Browser & Search (via Tor)")
    p.add_argument("cmd", choices=["search", "browse", "status"])
    p.add_argument("query", nargs="?", help="search query or URL to browse")
    p.add_argument("--limit", type=int, default=10)
    args = p.parse_args()

    if args.cmd == "status":
        is_tor, ip = check_tor()
        print(f"🟢 Tor connected: {is_tor} | Exit IP: {ip}")
        return
    if args.cmd == "browse":
        if not args.query:
            print("❌ URL required: darkweb.py browse <url>")
            return
        browse(args.query)
        return
    if not args.query:
        print("❌ Query required: darkweb.py search <query>")
        return

    print(f"🔍 Searching Tor network for: '{args.query}'\n")
    print("=== DDG (ONION) ===")
    results = search_ddg(args.query, args.limit)
    if not results:
        print("   (no results)")
    for i, r in enumerate(results, 1):
        print(f"  {i}. {r['title']}")
        print(f"     {r['url']}")
        if r.get("description"):
            print(f"     {r['description'][:120]}")
        print()
    print("💡 Tip: darkweb.py browse <url> to open a page")


if __name__ == "__main__":
    main()
