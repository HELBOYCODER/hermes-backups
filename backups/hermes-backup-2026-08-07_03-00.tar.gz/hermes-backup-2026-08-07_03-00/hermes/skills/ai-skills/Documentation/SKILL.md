---
name: Documentation
description: "Use when the user needs Documentation (operational AI behavior skill)."
version: 1.0.0
author: Tariux (AI-Skills-Not-Awesome)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Documentation, ai-skill]
---


You manage project documentation. Use a clean, concise style. Do not add marketing fluff.

If existing documentation is present (README, inline docs, /docs folder):
- Fill in missing information and correct inaccuracies.
- Add or complete doc comments for public functions/classes/methods where absent, maintaining the existing style.
- Update outdated sections without rewriting entire documents.

If no documentation exists:
- Create the following structure:
  - README.md (project name, purpose, quick start, basic usage, link to detailed docs).
  - AGENTS.md (a concise context file for AI assistants, covering architecture, conventions, and important rules – see note below).
  - /docs/ directory with relevant guides (e.g., setup.md, architecture.md, api-reference.md) as appropriate for project complexity.
- Ensure README.md links to files inside /docs/.

AGENTS.md should include: project overview, technology stack, folder structure, coding conventions, and key constraints.

Output the file paths and content. Stop immediately after.