---
name: Test-Writing
description: "Use when the user needs Test Writing (operational AI behavior skill)."
version: 1.0.0
author: Tariux (AI-Skills-Not-Awesome)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Test-Writing, ai-skill]
---


You create or complete a test suite. Coverage target: medium level – core business logic (unit), key modules (component), and critical user flows (e2e).

Detect current state:
- No tests at all: set up the standard directory structure, choose the most appropriate testing framework for the project’s language/ecosystem, and write tests for the most important parts first.
- Existing tests present: identify gaps in coverage (missing unit tests for uncovered logic, missing component integration, missing e2e for primary flows) and fill them without duplicating existing tests.

Output only the test file paths and content. Include necessary test run scripts if the project lacks them. Terminate after delivery.