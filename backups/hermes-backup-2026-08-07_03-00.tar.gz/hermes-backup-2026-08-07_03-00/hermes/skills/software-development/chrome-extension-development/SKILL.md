---
name: chrome-extension-development
description: Use when building or debugging Chrome extensions (MV3).
---

# Chrome Extension Development (MV3)

Build Chrome/Chromium extensions: session-cookie extractors, popup utilities, scraping tools.

## Structure (Manifest V3)

```
extension/
├── manifest.json    # MV3 manifest
├── popup.html       # popup UI
├── popup.js         # popup logic
└── icon16/48/128.png
```

## Cookie / Session Extraction Pattern

This is the most-requested use case (extract `__Secure-1PSID` etc. for Gemini Web / AI tools).

**manifest.json:**
```json
{
  "manifest_version": 3,
  "name": "...",
  "version": "1.0.0",
  "permissions": ["cookies", "clipboardWrite", "tabs"],
  "host_permissions": ["<all_urls>"],
  "action": { "default_popup": "popup.html", "default_icon": { "16": "icon16.png", "48": "icon48.png", "128": "icon128.png" } }
}
```
- `cookies` permission + `host_permissions` for the target domain are REQUIRED or `chrome.cookies.getAll` returns nothing.
- `<all_urls>` makes the tool work on ANY site — default to general unless user explicitly wants one site.

**Cookie fetch with parent-domain fallback** (`.google.com` catches `gemini.google.com`):
```js
const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
const host = new URL(tab.url).hostname;
const parts = host.split('.');
let cookies = await chrome.cookies.getAll({ domain: '.' + parts.slice(-2).join('.') });
if (cookies.length === 0) cookies = await chrome.cookies.getAll({ domain: host });
```

**Session cookie names to prioritize** (show first, badge as "Session"):
`__Secure-1PSID`, `__Secure-1PSIDTS`, `__Secure-3PSID`, `__Secure-3PSIDTS`, `SID`, `HSID`, `SSID`, `SAPISID`, `APISID`, `sessionid`, `connect.sid`, `token`, `auth_token`, `access_token`, `refresh_token`, `jwt`.

**Output format:** one `name=value` per line — the "Cookie header" value (omit the `Cookie:` prefix; consumers paste raw value). Add a "Copy all" button using `navigator.clipboard.writeText` with `document.execCommand('copy')` fallback.

Full working popup.js: see `references/session-cookie-extractor.md`.

## Icons (no designer needed)

Generate with PIL: transparent RGBA, filled circle/rounded rect, simple 4-point star polygon in white. One script, three sizes (16/48/128).

## Packaging for manual install

- `zip` binary may be MISSING on fresh servers → use Python: `python3 -c` / execute_code with `zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED)` writing each file at archive root (no folder prefix).
- Deliver the .zip via MEDIA: path in the reply.

**Install instructions to give user:**
1. Unzip
2. Chrome → `chrome://extensions`
3. Enable **Developer mode** (top-right)
4. **Load unpacked** → select folder

## Pitfalls

- **Site-specific vs general:** user said "only Gemini" but meant "Gemini is just an example" — when they ask for a cookie/tool extractor, build for ALL sites (`<all_urls>`), not one domain. Ask if ambiguous, default to general.
- `chrome.cookies.getAll({ domain })` needs exact or parent domain; subdomain (e.g. `gemini.google.com`) may miss parent-domain cookies — always try the parent `.domain.tld` first.
- Popup closes on focus loss; do extraction on button click, not on load.
- Clipboard in popup needs `clipboardWrite` permission; `navigator.clipboard` may still fail → keep `execCommand` fallback.
- RTL (Persian) popups: `dir="rtl"` on `<html>`, keep cookie values `direction: ltr; text-align: left` so values don't garble.

## Verification

1. `chrome://extensions` → Load unpacked → no manifest errors
2. Open logged-in target site (e.g. gemini.google.com)
3. Click extension icon → Extract → cookies listed with values
4. Copy → paste format has no `Cookie:` prefix
