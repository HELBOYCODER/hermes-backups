# Session Cookie Extractor — full working popup.js (MV3)

Known-good implementation, built 2026-08-05, delivered as `/root/session-cookie-extractor.zip`.
Works on ANY site; sorts session cookies first; outputs `name=value` lines (Cookie-header format, no `Cookie:` prefix).

```js
// Session Cookie Extractor - popup logic
// Reads cookies for whatever site the user is currently on (works on any site)

const extractBtn = document.getElementById('extract');
const copyBtn = document.getElementById('copy');
const statusEl = document.getElementById('status');
const resultsEl = document.getElementById('results');
const outputEl = document.getElementById('output');
const siteEl = document.getElementById('site');

// Cookies to highlight as "session" (shown first), then the rest
const SESSION_NAMES = [
  '__Secure-1PSID', '__Secure-1PSIDTS', '__Secure-3PSID', '__Secure-3PSIDTS',
  'SID', 'HSID', 'SSID', 'SAPISID', 'APISID',
  'sessionid', 'session', 'connect.sid', 'token', 'auth', 'auth_token',
  'access_token', 'refresh_token', 'id_token', 'jwt',
];

function setStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className = 'status ' + type;
  statusEl.style.display = 'block';
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function extractDomain(url) {
  try { return new URL(url).hostname; } catch (e) { return url; }
}

// Show current site on popup open
chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
  if (tab && tab.url) siteEl.textContent = '🌐 ' + extractDomain(tab.url);
});

extractBtn.addEventListener('click', async () => {
  statusEl.style.display = 'none';
  resultsEl.innerHTML = '';
  outputEl.style.display = 'none';
  copyBtn.style.display = 'none';

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || !tab.url.startsWith('http')) {
      setStatus('⚠️ No page open. Log into the target site first.', 'warn');
      return;
    }

    const host = extractDomain(tab.url);
    siteEl.textContent = '🌐 ' + host;
    setStatus('Extracting cookies from ' + host + '...', 'ok');

    // Parent-domain first (e.g. .google.com catches gemini.google.com)
    const domainParts = host.split('.');
    let cookies = [];
    if (domainParts.length >= 2) {
      const parent = '.' + domainParts.slice(-2).join('.');
      cookies = await chrome.cookies.getAll({ domain: parent });
      if (cookies.length === 0) {
        cookies = await chrome.cookies.getAll({ domain: host });
      }
    } else {
      cookies = await chrome.cookies.getAll({ domain: host });
    }

    // Sort: session cookies first, then alphabetical
    const isSession = c => SESSION_NAMES.some(n => c.name.toLowerCase().includes(n.toLowerCase()));
    cookies.sort((a, b) => {
      const sa = isSession(a) ? 0 : 1;
      const sb = isSession(b) ? 0 : 1;
      if (sa !== sb) return sa - sb;
      return a.name.localeCompare(b.name);
    });

    if (cookies.length === 0) {
      setStatus('❌ No cookies found! Make sure you are logged in and refresh.', 'err');
      return;
    }

    // Cookie-header format: name=value per line, NO "Cookie:" prefix
    let output = '';
    cookies.forEach(c => { output += c.name + '=' + c.value + '\n'; });

    // Render cookie cards (name + badges + selectable value)
    cookies.forEach(c => {
      const row = document.createElement('div');
      row.className = 'cookie-row';
      const badges =
        (c.secure ? '<span class="badge badge-secure">Secure</span>' : '') +
        (c.httpOnly ? '<span class="badge badge-http">HttpOnly</span>' : '') +
        (isSession(c) ? '<span class="badge" style="color:#a6e3a1;border-color:#a6e3a155">Session</span>' : '');
      row.innerHTML =
        '<span class="cookie-name">' + escapeHtml(c.name) + badges + '</span>' +
        '<span class="cookie-value">' + escapeHtml(c.value) + '</span>';
      resultsEl.appendChild(row);
    });

    setStatus('✅ ' + cookies.length + ' cookies extracted from ' + host, 'ok');

    outputEl.value = output;
    outputEl.style.display = 'block';
    copyBtn.style.display = 'block';
  } catch (e) {
    setStatus('❌ Error: ' + e.message, 'err');
  }
});

copyBtn.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(outputEl.value);
  } catch (e) {
    outputEl.select();
    document.execCommand('copy');
  }
  copyBtn.textContent = '✅ Copied!';
  setTimeout(() => { copyBtn.textContent = '📋 Copy all'; }, 1500);
});
```

## Key manifest bits

```json
{
  "manifest_version": 3,
  "permissions": ["cookies", "clipboardWrite", "tabs"],
  "host_permissions": ["<all_urls>"]
}
```

## Icon generation (PIL)

```python
from PIL import Image, ImageDraw
for size in (16, 48, 128):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([size*0.05, size*0.05, size*0.95, size*0.95], fill=(66, 133, 244, 255))
    cx, cy, r = size*0.5, size*0.5, size*0.22
    d.polygon([(cx, cy-r), (cx+r*0.3, cy-r*0.3), (cx+r, cy), (cx+r*0.3, cy+r*0.3),
               (cx, cy+r), (cx-r*0.3, cy+r*0.3), (cx-r, cy), (cx-r*0.3, cy-r*0.3)],
              fill=(255, 255, 255, 255))
    img.save(f'/path/icon{size}.png')
```

## Packaging without zip binary

```python
import zipfile, os
with zipfile.ZipFile('/root/out.zip', 'w', zipfile.ZIP_DEFLATED) as zf:
    for f in ['manifest.json', 'popup.html', 'popup.js', 'icon16.png', 'icon48.png', 'icon128.png']:
        zf.write(os.path.join(base, f), f)  # archive root, no folder prefix
```

## Session-cookie consumers (why this matters)

Gemini Web free-tier access (e.g. via OpenRouter-style gateways / browser-session providers) authenticates with `__Secure-1PSID` (+ optional `__Secure-1PSIDTS`) from gemini.google.com — no API key. The extracted value is pasted as the "credential" and must be refreshed when the session expires. Treat as password: grants access to the signed-in Google account until revoked.
