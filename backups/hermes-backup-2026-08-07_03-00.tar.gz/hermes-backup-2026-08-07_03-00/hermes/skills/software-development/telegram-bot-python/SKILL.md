---
name: telegram-bot-python
description: "Use when building or debugging Python Telegram bots."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [telegram, bot, python-telegram-bot, ptb, polling, filters, getUpdates]
  related_skills: [self-hosted-services]
---

# Telegram Bot Development (python-telegram-bot)

Build, debug, and run Telegram bots written with the `python-telegram-bot` library (PTB v20+).

## Workflow

1. **Verify the token before writing code**:
   ```bash
   curl -s https://api.telegram.org/bot<TOKEN>/getMe
   ```
   `200` + `"ok":true` = valid. `401` = wrong token; `409` = token already in use by another bot instance.
2. **Check the token is not already in use on the server**: grep for it across `/opt/*/` bot sources and check `docker ps` — two processes polling the same token will fight (see Pitfalls).
3. **Build the bot**: `Application.builder().token(TOKEN).build()`, add handlers, then
   `app.run_polling(allowed_updates=Update.ALL_TYPES)`.
4. **Run it**: `terminal(background=true)` + `notify_on_complete=true` while debugging; promote to a systemd service or Docker container once stable (see `self-hosted-services` skill).
5. **Test conversions/handlers directly** with a one-off Python script instead of restarting the bot repeatedly (faster iteration; avoids token conflicts with the running instance).

## Pitfalls

### Filters do NOT compose with `|` in PTB v20+
The filters namespace mixes classes and instance constants, and `|` composition breaks in surprising ways:

- `filters.Document` is a **class** (capital D), while `filters.AUDIO`, `filters.VIDEO`, `filters.PHOTO`, `filters.VOICE` are **instance constants**.
- `filters.Document | filters.AUDIO` → `TypeError: unsupported operand type(s) for |: 'type' and '_Audio'`
- `filters.Document() | filters.AUDIO` → `TypeError: unsupported operand type(s) for |: 'Document' and '_Audio'`

**Robust pattern — do not burn time composing filters:**
```python
app.add_handler(MessageHandler(filters.ALL, handle_file))

async def handle_file(update, context):
    m = update.message
    if m.document: ...      # file attachment
    elif m.audio: ...       # audio
    elif m.video: ...       # video
    elif m.photo: ...       # photo (list of sizes)
    elif m.voice: ...       # voice note
    else: return
```
`filters.ALL` catches every message; check `update.message.<type>` attributes inside the handler. Simple, version-proof, and the message object attributes mirror the filter names.

### `Conflict: terminated by other getUpdates request` = token already polling
This error means **another running process polls the same bot token** (a leftover background process, a Docker container, or a second bot you started with the same token). Diagnose:

```bash
ps aux | grep -E "bot.py|telegram_bot" | grep -v grep
docker ps   # containers running bots
```

Each bot needs its **own** token from @BotFather. You cannot run two bots on one token — the newer instance dies with `telegram.error.Conflict`. Fix: stop the old instance, or get a fresh token and update the new bot's `BOT_TOKEN`.

**Nuance — 409 can be a POSITIVE signal.** If a systemd service (or tracked background process) is already running the bot, a *manual* `getUpdates` probe returns exactly this 409 — that proves the service is alive and polling. Don't treat it as an error; confirm with `systemctl is-active <svc>` + `pgrep -f bot.py` and move on. The 409 only kills a *new* instance you just started (two pollers fighting the same token).

### Kill the old instance before restarting during dev
PTB keeps polling; restarting while the old process lives produces the same Conflict error. Kill via `process(action=kill)` (for Hermes-tracked background procs) or `pkill -f bot.py` first.

### Local `telegram/` dir shadows the installed `telegram` package
If the project has its own `telegram/` subpackage (e.g. `telegram/reporter.py`) AND python-telegram-bot (or the `telegram` PyPI package) is installed, `from telegram.reporter import ...` can resolve against the installed package and die at runtime with `ModuleNotFoundError: No module named 'telegram.reporter'` — even though a quick import test passes. Bypass package resolution and load the file directly:

```python
import importlib.util
spec = importlib.util.spec_from_file_location("tg_reporter", "/opt/<proj>/telegram/reporter.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
self.reporter = mod.TelegramReporter(...)
```

Or rename the local dir. Seen in the trading-bot build: the error surfaced only inside the systemd service, not in a standalone import check.

### `Bad Request: chat not found` on first message = user hasn't /started yet
A fresh bot cannot push messages to a `chat_id` until the user has at least messaged the bot (pressed Start). The startup greeting fails with HTTP 400 `chat not found`; the bot is fine — it just has no chat yet. Tell the user to open the bot and `/start` it, then resend. Don't chase this as a bug or a token problem.

### Downloader bots: distinguish host/network failure from code failure
When testing URL-download logic, a `httpx.ConnectError: No address associated with hostname` (DNS) or connection reset for one host does **not** mean the code is broken — the server may block that host. Retry against a well-known reachable host (e.g. `https://httpbin.org/robots.txt`) before debugging the client. Test the download/convert pipeline as a standalone one-off script (Workflow step 5) so network issues stay isolated from bot-loop issues.

## File size limits: 50MB cloud cap → 2GB via Local Bot API Server

Telegram cloud Bot API hard-caps upload/download at **50MB per file** — nothing raises it from the cloud side. The only path to **2GB** is the **Telegram Local Bot API Server** (a `tdlib`-based C++ binary from `github.com/tdlib/telegram-bot-api`) running on a server you control, in front of the cloud API.

- PTB wiring: `Application.builder().token(T).base_url(f"{local_base}/bot{T}")`. Health-check the local server first and fall back to the cloud API so the bot survives a local-server outage.
- **It cannot run on Supabase**: Edge Functions are Deno with 256MB memory, 150s execution, ~10MB response cap — no native binaries, and 2GB files can't pass through. "2GB with only Supabase" is impossible; the Local Bot API server needs an owned VPS (or accept 50MB). State this plainly to the user and offer the trade-off.
- The Local Bot API server additionally needs the user's **api_id/api_hash** from my.telegram.org. When the manual browser flow fails, automate it **gently** — my.telegram.org rate-limits rapid retries ("Sorry, too many tries", cooldown ~1 hour — 30 min is NOT enough); send ONE request per attempt with browser-like headers and human pauses, and never retry before the cooldown (see `references/large-file-limits-and-local-api.md`).

Fallback builder pattern (cloud API if local server down):
```python
builder = Application.builder().token(BOT_TOKEN)
local_base = os.getenv("LOCAL_BOT_API", "http://127.0.0.1:8081")
try:
    r = httpx.get(f"{local_base}/getMe", params={"token": BOT_TOKEN}, timeout=3)
    if r.status_code == 200:
        builder = builder.base_url(f"{local_base}/bot{BOT_TOKEN}")
except Exception:
    pass  # cloud API (50MB cap) as fallback
app = builder.build()
```

## Custom emoji sticker sets (custom_emoji)

Creating emoji that appear in the keyboard emoji panel (`sticker_type: custom_emoji`):
the image must be **exactly 100x100 px** (not 512x512!) — 512 fails with
`STICKER_PNG_DIMENSIONS` even though the same file creates a `regular` set fine.
Full stdlib-only recipe (multipart upload → createNewStickerSet → verify →
t.me/addstickers link), Premium requirement, and cleanup: see
`references/custom-emoji-sticker-sets.md`.

## No-persistence rule (this user's bots)

Bots deployed for this user must **never store files on the server**: download → convert → send → delete temp files only. Concretely:

- Write temp files under `/tmp` only, and delete them in a `finally` block right after upload succeeds.
- If a database (e.g. Supabase REST) is used, it holds logs/state only — never file content. Purge log rows after each message (e.g. `DELETE ... WHERE id != 0` against `download_log`) so the DB stays empty. This user explicitly asked for zero persistent footprint; check with them before any design that keeps files.

## References

- `references/python-telegram-bot-filters.md` — exact error transcripts and the working fix from the file-converter bot build.
- `references/url-downloader-bot.md` — full no-persistence bot pattern: httpx stream download → send → delete, Supabase log purge, verification sequence (getMe → unit install → 409-as-alive → standalone stream test).
- `references/large-file-limits-and-local-api.md` — size-cap matrix, Local Bot API server setup notes, api_id/api_hash auto-extraction when my.telegram.org manual flow fails: verified "too many tries" rate-limit cooldown (~1h), gentle human-like pacing rules (one request per attempt, browser headers, human pauses), `/apps/create` flow, GitHub-first tool research pattern. **Confirmed dead end: app creation is IP-restricted — both accounts and a Tor exit IP all return bare `ERROR`; only a real residential IP works. `stel_token` is IP-bound; 401 on create = expired session.**
- `references/custom-emoji-sticker-sets.md` — custom emoji via Bot API: 100x100px requirement (512 → `STICKER_PNG_DIMENSIONS`), stdlib multipart upload recipe, createNewStickerSet payload, Premium limitation, cleanup/verification.
- `templates/telegram-bot.service` — systemd unit template for a PTB bot; sed-inject the token, enable, start.
