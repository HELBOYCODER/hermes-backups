# Custom Emoji Sticker Sets via Bot API (custom_emoji)

## The non-obvious requirement (main pitfall)

`Bad Request: STICKER_PNG_DIMENSIONS` (400) on `createNewStickerSet` with
`sticker_type: "custom_emoji"` almost always means the image is **not exactly
100x100 pixels**. A 512x512 PNG/WebP uploads fine and creates a `regular`
set, but the SAME file fails for `custom_emoji` — the error message never
tells you the right size. Source (core.telegram.org/stickers):

> For stickers, one side must be exactly 512 pixels in size — the other side
> can be 512 pixels or less. **For emoji, images must be exactly 100x100
> pixels in size.** The image file must be in either .PNG or .WEBP format.

- Regular/mask static stickers: 512x512 (one side exactly 512, other ≤512), PNG or WebP.
- Custom emoji static: **exactly 100x100**, PNG or WebP.
- Verify the real on-disk dims by parsing the PNG IHDR chunk — don't trust a
  prior resize; PIL reports what you saved, Telegram checks what it reads.

## Recipe (stdlib only — no `requests` needed)

1. **Resize**: `Image.open(src).convert("RGBA").resize((100, 100), Image.LANCZOS)`, save PNG.
2. **Upload** (`uploadStickerFile`, multipart, fields `user_id`,
   `sticker_format=static`, file in the `sticker` field):
   ```python
   boundary = "----bnd"
   body = b""
   for k, v in {"user_id": "123", "sticker_format": "static"}.items():
       body += f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode()
   body += f"--{boundary}\r\nContent-Disposition: form-data; name=\"sticker\"; filename=\"e.png\"\r\nContent-Type: image/png\r\n\r\n".encode()
   body += png_bytes
   body += f"\r\n--{boundary}--\r\n".encode()
   # POST https://api.telegram.org/bot<TOKEN>/uploadStickerFile
   ```
3. **Create set** (`createNewStickerSet`, JSON):
   ```json
   {
     "user_id": 123,
     "name": "erfan_emoji_by_<bot_username>",
     "title": "My Emoji 🎧",
     "sticker_format": "static",
     "sticker_type": "custom_emoji",
     "stickers": [{"sticker": "<FILE_ID>", "emoji_list": ["🎧", "🎵"]}]
   }
   ```
   `emoji_list` may hold several emoji per sticker.
4. **Verify**: `getStickerSet?name=...` — check `sticker_type == custom_emoji`,
   sticker `width`/`height` == 100x100, and the returned `file_id` prefix
   (`CAAC...` for stickers vs `BQAC...` for uploaded files).
5. **Share**: tell the user to open `t.me/addstickers/<name>` in Telegram and
   press Add.

## Pitfalls

- **Name MUST end with `_by_<bot_username>`** (case-insensitive) — otherwise 400.
- To reuse a name after a failed attempt, `deleteStickerSet` first — recreating
  over an existing set errors.
- **Using custom emoji in messages requires Telegram Premium** — Telegram's
  limitation, not the API's. Without Premium the user can still add the set
  but can't type it in chats. Say this plainly, and offer the same art as a
  `regular` sticker set as a fallback (same upload, just `sticker_type: regular`
  and 512x512 art).
- `custom_emoji` sets hold up to **200** stickers via `addStickerToSet`
  (others cap at 120).
- `needs_repainting: true` is custom_emoji-only — makes the emoji recolor to
  message text / emoji-status accent / chat-photo white.
- Static sticker art tip from Telegram: transparent background + white stroke
  + black shadow makes it stand out.

## Worked example

Built "Erfan Music Emoji 🎧" (headphones + letter E + gold note + equalizer):
- First attempt: 512x512 WebP → `STICKER_PNG_DIMENSIONS` on custom_emoji, but
  same file → `regular` set created fine (proof the file itself was valid).
- Fix: resize to 100x100 PNG → upload → create custom_emoji → `ok: true`.
- Deleted the throwaway regular set with `deleteStickerSet` afterwards.
