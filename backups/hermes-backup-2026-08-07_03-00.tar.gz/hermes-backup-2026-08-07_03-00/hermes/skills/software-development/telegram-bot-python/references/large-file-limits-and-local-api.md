# Telegram file-size caps, Local Bot API, and api credential extraction

## Size cap matrix (verified when user asks for "2GB" or "50MB+" support)

| Path | Per-file cap | Where it runs | Notes |
|------|-------------|---------------|-------|
| Cloud Bot API (`api.telegram.org`) | **50MB** download, 50MB upload | Telegram infra | Only option for plain bots; nothing raises it |
| Local Bot API Server | **2GB** (up to 2000MB) | A server YOU control | C++ binary from `github.com/tdlib/telegram-bot-api`; runs as a proxy in front of the cloud API |
| Supabase Edge Function | ~10MB HTTP response | Supabase | Deno runtime: **256MB memory, 150s timeout**, no native binaries — cannot host the Local Bot API server, cannot buffer 2GB |

**Decision framing for the user:** "2GB with only Supabase" is not achievable — the Local Bot API server is a compiled binary that must run on owned infrastructure. Offer: (A) Supabase-only → 50MB cap; (B) Supabase logic + Local Bot API binary on the VPS → 2GB cap; (C) whole bot on VPS → 2GB cap.

## Local Bot API server notes

- Binary: `telegram-bot-api` from `github.com/tdlib/telegram-bot-api` (build with tdlib, or use prebuilt release binaries).
- Requires **api_id + api_hash** from my.telegram.org — the cloud `getMe` token alone is not enough.
- Run on `127.0.0.1:8081`; PTB clients use `base_url = http://127.0.0.1:8081/bot<TOKEN>`.
- Health check before switching the bot to it: `curl http://127.0.0.1:8081/getMe?token=<TOKEN>`.
- Keep a cloud-API fallback in the builder (see SKILL.md) so the bot survives local-server restarts.

## Automating api_id / api_hash extraction (manual my.telegram.org flow fails)

Package: `pip install api-id-api-hash` (MIT, ~3KB pure Python; `requests` + `BeautifulSoup`).

**Security review before install (do this for any small third-party tool):** `pip download` the wheel, unzip it, read the `.py` sources. This one is clean: it only talks to `my.telegram.org` (send_password → login → /apps), stores no data, no exfiltration.

Flow (needs the user's phone number + OTP code from their Telegram app):
```python
from api_id_hash import TelegramAPIExtractor
x = TelegramAPIExtractor()
random_hash = x.send_auth_password("+98912...")   # triggers OTP to user's Telegram
token = x.login_with_code("+98912...", random_hash, "<OTP>")
app_id, app_hash = x.get_api_details(token)        # scraped from my.telegram.org/apps
```

Pitfalls:
- Phone must include country code (`+98...` for Iran).
- OTP arrives in the Telegram app, not SMS, for many accounts.
- If the account has **no developer app yet**, `/apps` shows a creation form instead of values — `get_api_details` returns `None, None`; the user must create an app once via my.telegram.org (or the tool's flow may still work after first creation).

## Rate limits: "Sorry, too many tries" (verified behavior)

`my.telegram.org` hard-rate-limits the phone number. Observed: after a few rapid `send_password` POSTs (initial attempts + a retry ~45s later), it returned HTTP 200 with body `Sorry, too many tries. Please try again later.` A second attempt after another 90s still failed. **Verified cooldown: ~1 hour.** A single retry exactly 30 min after the ban was STILL rate-limited; a single retry ~1 hour after the ban succeeded (OTP sent, status 200). Community tools warn "try again in 8 hours" for the worst case. Rules:

- **Never retry faster than ~1 hour apart** once "too many tries" appears — each early retry extends the ban window (30 min was proven insufficient).
- Schedule ONE retry (e.g. `terminal(background=true)` with `sleep 3600` + notify) rather than looping.
- The message appears in the JSON/text body of the `send_password` response — detect it before calling `.json()`.

## Gentle, human-like automation (this user's explicit requirement)

The user requires ANY site login automation to be slow and human-like so the site can't detect a bot ("خیلی آروم و انسانی... یک بار ریکوئست بفرست"). Working pattern (v2 script, `/opt/api-id-api-hash/gentle_extract.py`):

1. **One request per attempt.** No loops, no parallel calls. If rate-limited, stop and wait, don't hammer.
2. **Full browser headers** on the requests.Session: Chrome UA + `Accept`, `Accept-Language`, `Sec-Fetch-*`, `Upgrade-Insecure-Requests`. Missing headers (plain `requests` defaults) are a bot fingerprint.
3. **Human behavior**: GET `/auth` first (browser always loads the page before POSTing), then random pauses `time.sleep(random.uniform(2, 5))` between steps, `human_pause` between login → /apps → create.
4. **Split the flow across time**: OTP send → pickle the session + `random_hash` to `/tmp/tg_session.pkl` → wait for the user's code → second invocation logs in with the code and extracts. Never hold the user's code in the same run as the OTP request; a stale OTP expires.
5. **Login detection**: after `POST /auth/login`, success = `stel_token` cookie present. **Save the cookie with the session — and do the pickle dump AFTER login**, not before. Bug seen in practice: the v2 script pickled only `phone`+`random_hash` before login, so the retry invocation had no `stel_token`; its GET `/apps` then returned the login page ("Authorization … Log in here to manage your apps") and CSRF lookup found nothing. The fix is a second `pickle.dump` immediately after `stel_token` is detected, so a failed app-creation can be retried WITHOUT a fresh OTP.

## App creation when the account has no developer app

If `/apps` lacks the `App api_id:` label (BeautifulSoup: `soup.find("label", string="App api_id:")`), the account needs one app created first:

The `/apps` page also carries a hidden CSRF token that the create POST **must** include: `<input type=hidden name=hash value=...>` in the form. Fetch it fresh from GET `/apps` (parse with BeautifulSoup) right before POSTing — sending create without it (or with a stale one) yields "Invalid hash" errors:

```python
soup = BeautifulSoup(session.get("https://my.telegram.org/apps", headers=h).text, "html.parser")
csrf = soup.find("input", {"type": "hidden", "name": "hash"})["value"]
session.post("https://my.telegram.org/apps/create", data={
    "hash": csrf, "app_title": "ERSAZ App", "app_shortname": "ersazapp",
    "app_url": "", "app_platform": "desktop", "app_desc": "Personal applications",
}, headers={"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Origin": "https://my.telegram.org", "Referer": "https://my.telegram.org/apps"})
```

Then re-fetch `/apps` and parse labels. Verified pitfall: an earlier session logged in successfully (stel_token obtained) but the tool's `get_api_details` returned nothing because the app didn't exist — the login itself is NOT the failure point; check for the missing-app case before blaming the token.

## GitHub-first tool research

When automating any login flow: search GitHub for mature tools BEFORE writing your own, then review and borrow their proven parsing instead of guessing selectors:

```bash
curl -s "https://api.github.com/search/repositories?q=<topic>+in:name,description&sort=stars&per_page=15"
```

- Sort by stars, check `updated_at` for recency, read the code (never run blind — pip-download/unzip or clone + read first).
- `esfelurm/Apis-Telegram` (34★, updated 2026-07) has the best apps-page parser: label-based `soup.find("label", string="App api_id:")` → sibling `div` → `span`. More robust than class-based selectors.

## Known dead end (CONFIRMED 2026-08): `/apps/create` returns bare `ERROR` = IP-restricted

On this user's VPS (45.38.249.235, EGIHosting, US datacenter IP), the whole pre-create flow succeeds — OTP send, login, `stel_token`, fresh CSRF — but **every** `/apps/create` POST returns HTTP 200 with body exactly `ERROR`, regardless of: unique shortname, platform, or `app_url`. The user's own manual browser attempt on the same network also failed. **CONFIRMED IP-based restriction, not account-based** — both discriminators ran:

- **Second account** (+1... phone) from same IP: same `ERROR` → rules out an account-level flag.
- **Full flow via Tor exit IP** (fresh OTP → login → create all through `socks5h://127.0.0.1:9050`): still `ERROR` → Tor exit nodes are also flagged. "Just proxy it" does NOT solve this.

The only remaining path is a genuine residential IP (user's home browser / phone hotspot). Do NOT re-run create attempts on datacenter or Tor IPs — they all return `ERROR`. MTProto-based generators take a different path but are still web-driven (`staliox/Telegram-API-Generator` hits the same my.telegram.org web form and rate limits); no known bypass.

### Session token is IP-bound (verified)
`stel_token` is tied to the IP that logged in. Reusing a session created on the server IP through a different proxy (e.g. Tor) makes GET `/apps` return the **login page** ("Log in here to manage your apps") — the session silently dies, no error. If you must route through a proxy, the ENTIRE flow (OTP → login → create → scrape) must go through the SAME proxy from the start. Pickle the session and dump AGAIN immediately after `stel_token` appears (post-login), never before.

### 401 on POST /apps/create = expired session, NOT a create failure
`stel_token` is short-lived. A 401 `Unauthorized` on create means the pickled session is stale → discard, request a fresh OTP, redo the flow. Distinguish the three failure signatures: **200 + body `ERROR`** = IP restriction; **401** = expired session; **200 + "too many tries"** = rate limit.

### Tor proxy setup for requests (reusable technique)
```bash
apt-get install -y tor && systemctl start tor   # socks5h://127.0.0.1:9050
pip3 install --break-system-packages pysocks    # REQUIRED — without it requests errors "Missing dependencies for SOCKS support"
```
```python
s.proxies.update({"http": "socks5h://127.0.0.1:9050", "https": "socks5h://127.0.0.1:9050"})
```
Verify the exit IP (`curl --socks5-hostname 127.0.0.1:9050 https://api.ipify.org`) before relying on it. Caveat: Tor exit IPs are still flagged by Telegram for app creation (→ `ERROR`), so Tor is NOT a residential-IP substitute for this particular flow.
