# python-telegram-bot Filter Composition — Error Transcript

From the file-converter bot build (PTB v20+, `/opt/file-converter-bot/bot.py`).

## Attempt 1: class `|` constant

```python
MessageHandler(filters.Document | filters.AUDIO | filters.VIDEO | filters.PHOTO | filters.VOICE, handle_file)
```

```
TypeError: unsupported operand type(s) for |: 'type' and '_Audio'
```

`filters.Document` (capital D) is the **class** `_Document`; `filters.AUDIO` is an **instance** of `_Audio`. `|` between a class and an instance is not supported.

## Attempt 2: instantiate the class

```python
MessageHandler(filters.Document() | filters.AUDIO | filters.VIDEO | filters.PHOTO | filters.VOICE, handle_file)
```

```
TypeError: unsupported operand type(s) for |: 'Document' and '_Audio'
```

Even `filters.Document()` (now a `Document` instance) refuses to compose with the `_Audio` constant. In this installed version the `|` operands must be the same filter family — mixing the document-family instance with audio-family constants fails.

## Attempt 3 (works): `filters.ALL` + manual attribute checks

```python
app.add_handler(MessageHandler(filters.ALL, handle_file))

async def handle_file(update, context):
    m = update.message
    if m.document:
        ...   # generic file
    elif m.audio:
        ...
    elif m.video:
        ...
    elif m.photo:
        ...   # m.photo is a list of PhotoSize, largest last
    elif m.voice:
        ...
    else:
        return
```

## Token conflict (follow-up)

After the filter fix the bot died again with:

```
telegram.error.Conflict: Conflict: terminated by other getUpdates request;
make sure that only one bot instance is running
```

Root cause: the token was the same one the HaveAll bot (`haveall_telegram_bot` Docker container, `python telegram_bot.py`) was already polling. Diagnosis:

```bash
ps aux | grep -E "telegram_bot|bot.py" | grep -v grep
docker ps
```

Resolution: each bot needs its own token from @BotFather (`/newbot`). Reusing a token means the second instance dies with Conflict.

## Lessons

1. Never try to compose PTB filters with `|` when mixing capital-letter classes with lowercase constants — just use `filters.ALL` and branch on `update.message.<type>` attributes.
2. Before building a new bot on a shared server, verify the token isn't already polling: `curl -s https://api.telegram.org/bot<TOKEN>/getMe` returns `409` when the token is in use by another getUpdates loop.
3. Kill the previous instance before relaunching during development (`process action=kill` or `pkill -f bot.py`).
