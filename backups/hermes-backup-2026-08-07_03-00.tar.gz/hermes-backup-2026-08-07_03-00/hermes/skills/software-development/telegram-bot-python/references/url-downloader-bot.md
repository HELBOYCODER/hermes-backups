# No-Persistence URL Downloader Bot — Verified Pattern

From the @ERSAZURLDLbot build (`/opt/url-downloader-bot/bot.py`, httpx + python-telegram-bot v20+). Verified end-to-end: token OK, service active, download stream tested standalone.

## Architecture (zero persistent footprint)

```
user sends URL → httpx stream download to /tmp → send file to Telegram → delete /tmp file (finally)
                                                                     → purge Supabase log rows
```

- Files NEVER enter the database — only a log row (url, status, size) is inserted.
- After each send: `os.remove(tmp_path)` in `finally` + `DELETE FROM download_log WHERE id != 0` via Supabase REST.
- Result: server disk and DB both return to baseline after every message.

## Supabase REST log + purge (no python client lib needed)

New-style keys (`sb_publishable_...`) break the old `supabase-py` client — use plain REST with the publishable key as `apikey`/`Authorization` header:

```bash
# insert log row
curl -s -X POST "https://<ref>.supabase.co/rest/v1/download_log" \
  -H "apikey: $KEY" -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" -H "Prefer: return=minimal" \
  -d '{"url":"...","status":"ok"}'

# purge all rows after send
curl -s -X DELETE "https://<ref>.supabase.co/rest/v1/download_log?id=neq.0" \
  -H "apikey: $KEY" -H "Authorization: Bearer $KEY"
```

Create the table directly over Postgres when the REST 404s (table missing):
`CREATE TABLE IF NOT EXISTS download_log (id bigint generated always as identity primary key, url text, status text, created_at timestamptz default now());`

## Verification sequence (in order)

1. `curl -s https://api.telegram.org/bot<TOKEN>/getMe` → 200 + `"ok":true` = token valid. Do this BEFORE writing any code.
2. Install systemd unit (see `templates/telegram-bot.service`): cp → `sed -i 's|BOT_TOKEN=CHANGE_ME|BOT_TOKEN=<real>|'` → `daemon-reload` → `enable` → `start` → `systemctl is-active` = `active`.
3. Logs: `journalctl -u <svc> --no-pager -n 15`.
4. Manual `getUpdates?limit=1` probe → **409 Conflict is expected and GOOD here**: it proves the service's own poller holds the token. (Only a 409 that kills a freshly started instance is a real conflict.)
5. Test download logic standalone (never through the live bot):
   ```python
   async with httpx.AsyncClient(follow_redirects=True, timeout=30) as client:
       async with client.stream("GET", url) as r:
           r.raise_for_status(); total = 0
           async for chunk in r.aiter_bytes(65536): total += len(chunk)
   ```
   If one host fails with `ConnectError: No address associated with hostname` (DNS), retry with a different well-known host (e.g. `https://httpbin.org/robots.txt`) before suspecting the code.

## Pitfalls hit

- Old `supabase-py` client rejects `sb_publishable_*` keys → switch to raw REST with the publishable key in headers.
- Reusing another bot's token → `telegram.error.Conflict` (see SKILL.md Pitfalls; this bot got a fresh @BotFather token).
- Telegram file upload cap ~50 MB — enforce a download size limit and reject larger URLs with a clear message.
