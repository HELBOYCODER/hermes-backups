# MQL5 (MetaQuotes) web session auth via cookies

Verified 2026-08: user pasted mql5.com cookies from their browser → session usable for profile/account management. Not trading access.

## Cookies needed
- `auth` (httpOnly, `.mql5.com`) — session auth token
- `sid` (httpOnly, `.mql5.com`) — ASP.NET-style session id, URL-encoded (contains `%2F` etc.)
- `lang=en` optional

Send all in one `Cookie` header with a real browser UA (Chrome/Windows). Session binds to the IP it was created on — changing IP/proxy invalidates it.

## Verify login state
Fetch `https://www.mql5.com/en` with the cookies. **Logged in ⟺ page contains `href="/en/auth_logout"`.** Bare 200 is NOT proof (public page). Don't trust `/en/users` (404 without username) or `/en/account` (404) — wrong paths, not session failures.

## Extract the username
Profile-management links near the logout link reveal the login handle:
```
/en/users/<username>/accounting/topup
/en/users/<username>/accounting/chooseout
/en/users/<username>/edit
```
Recipe: find `auth_logout` in the body, take ~500 chars before it, regex `/en/users/([^"/]+)`. Profile page then loads at `https://www.mql5.com/en/users/<username>` (title = display name + login).

## What the session gives
- Profile page + display name
- MQL5 service balance / topup / chooseout pages (account management)
- Logged-in Forum / Market / Signals browsing

## What it does NOT give
- **MT5 terminal trading.** The web session never substitutes for MetaTrader terminal login with broker credentials. For automated trading: EA on the user's Windows MT5 + Python connector polling the server signal API (see SKILL.md "MetaTrader 5 execution paths").

## Pitfalls
- `sid` value is URL-encoded — copy verbatim, never decode/re-encode.
- Response body is ~215KB — regex over it, don't print it.
- Logout link presence check beats trying to find "Login" links (logged-in pages have none).
