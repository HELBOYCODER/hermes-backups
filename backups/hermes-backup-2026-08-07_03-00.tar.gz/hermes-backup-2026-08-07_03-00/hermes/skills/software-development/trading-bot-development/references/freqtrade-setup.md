# Freqtrade Integration — Verified Setup (Aug 2026)

Freqtrade 2026.7 installed in a dedicated venv at `/opt/freqtrade` on 45.38.249.235.
Strategy: `ErfanStrategy.py` in `user_data/strategies/`. Config: `config_mexc.json`.

## Install

```bash
python3 -m venv /opt/freqtrade-venv
source /opt/freqtrade-venv/bin/activate
pip install freqtrade
```

## Data (must download before any backtest/hyperopt)

```bash
freqtrade download-data --config config_mexc.json --timeframe 1h --timerange 20260501-
```

3 months × 1 symbol ≈ 5s. Add pairs to config or `--pairs BTC/USDT SOL/USDT ETH/USDT`.

## Hyperopt extra deps (base install does NOT include them)

```bash
pip install filelock scikit-learn optuna
```

Without these, hyperopt fails with: `ERROR - No module named 'filelock'. Please ensure that the hyperopt dependencies are installed.` (or `optuna` on the next attempt).

## Strategy: hyperopt-ready param conversion

freqtrade's hyperopt needs `IntParameter` / `DecimalParameter` objects, not plain ints/floats. Error without them:

```
The 'buy' space is included into the hyperoptimization but no parameter for this space was found in your Strategy. Please make sure to have parameters for this space enabled for optimization or remove the 'buy' space from hyperoptimization.
```

### Pattern

```python
from freqtrade.strategy import IStrategy, informative, IntParameter, DecimalParameter

class MyStrategy(IStrategy):
    # BEFORE (no hyperopt):
    ema_fast = 9
    bb_std = 2.0

    # AFTER (hyperopt-ready):
    ema_fast = IntParameter(5, 21, default=9, space="buy")
    bb_std = DecimalParameter(1.5, 2.5, default=2.0, decimals=1, space="buy")
    rsi_sell = IntParameter(55, 75, default=60, space="sell")
    buy_signal_required = IntParameter(1, 3, default=2, space="buy")
    sell_signal_required = IntParameter(1, 3, default=2, space="sell")
```

ALL subsequent references must use `.value`:
```python
# populate_indicators:
dataframe["ema_fast"] = ta.EMA(dataframe, timeperiod=self.ema_fast.value)
bollinger = qtpylib.bollinger_bands(..., stds=self.bb_std.value)

# populate_entry_trend:
dataframe.loc[(buy_score >= self.buy_signal_required.value) & ...]
```

Leave constants that should NOT be optimized as plain values (use_exit_signal, stoploss, timeframe, startup_candle_count, trailing_stop, etc.).

## Run hyperopt

```bash
cd /opt/freqtrade
freqtrade hyperopt --config config_mexc.json --strategy ErfanStrategy \
  --hyperopt-loss SharpeHyperOptLoss --epochs 40 --timerange 20260501-
```

40 epochs takes minutes → run via `background=true + notify_on_complete=true` (foreground tool caps at 600s).

## Backtest divergence warning

The same strategy backtested at +64% in a custom STRATEGY_REVERSE engine scored ~0% in freqtrade's first backtest.

**Why:** Exit logic differs between engines. Our custom engine closes on signal reversal (`close_reason = STRATEGY_REVERSE`). freqtrade's default exits use `minimal_roi` / `exit_profit_only` / `exit_profit_offset` — fundamentally different exit semantics. **Backtest numbers never transfer between engines.** Re-tune in the target engine via hyperopt; don't panic at the first freqtrade backtest.

## config_mexc.json essentials

```json
{
  "dry_run": true,
  "trading_mode": "spot",
  "exchange": { "name": "mexc", "pair_whitelist": ["BTC/USDT"] },
  "pairlists": [{ "method": "StaticPairList" }],
  "strategy": "ErfanStrategy",
  "timeframe": "1h",
  "use_exit_signal": true,
  "exit_profit_only": false,
  "stoploss": -0.05,
  "trailing_stop": true,
  "trailing_stop_positive": 0.01,
  "trailing_stop_positive_offset": 0.03,
  "minimal_roi": { "0": 0.08, "30": 0.04, "60": 0.02, "120": 0 },
  "api_server": {
    "enabled": true,
    "listen_ip_address": "0.0.0.0",
    "listen_port": 8092,
    "username": "user",
    "password": "pass"
  }
}
```

- `dry_run: true` = paper mode (no real money)
- api_server **requires** `username` key (missing = `InvalidConfiguration`)
- fee shown in logs: 0.05% worst-case (MEXC default tier)

## Pair selection decides the backtest result (verified Aug 2026)

Same strategy, same engine, same period (2026-05-03 → 08-06, MEXC 1h):

| Pair whitelist | Trades | Win% | Result |
|---|---|---|---|
| BTC/ETH/SOL (3 majors) | 54 | 48.1% | −0.04% (~flat) |
| 24 pairs: majors + volatile alts (PEPE/WIF/BONK/FET/RNDR/TAO/INJ/SUI/APT/TIA/SEI/ARB/OP/NEAR/AVAX/LINK/DOGE...) | 282 | 63.8% | **+77.23 USDT (+0.77%)**, Sharpe 4.64, max DD 0.57% |

**Lesson:** a strategy tuned on altcoin momentum looks dead on flat majors (BTC/ETH/SOL were range-bound that window). When a backtest comes back ~0%, **expand `pair_whitelist` toward volatile symbols BEFORE touching params** — pair universe is the biggest lever.

## Verified hyperopt best params (ErfanStrategy, SharpeHyperOptLoss, 40 epochs)

```python
# Buy: ema_fast=11, ema_slow=29, rsi_period=7, rsi_buy=31, adx_min=21,
#      ema_trend=8, buy_signal_required=2, bb_std=1.9(ish)
# Sell: rsi_sell=55, sell_signal_required=1
minimal_roi = { "0": 0.328, "132": 0.055, "755": 0.029, "2006": 0 }
stoploss = -0.263          # very wide!
trailing_stop = True
trailing_stop_positive = 0.005
trailing_stop_positive_offset = 0.02
trailing_only_offset_is_reached = True
max_open_trades = 3
```

This strategy wins via **wide stoploss + trailing** (let winners run, ratchet after +0.5%/+2%), not tight SLs. Apply hyperopt output by string-replacing the defaults in the strategy file, then re-run backtesting to confirm.

## Pitfall: port collisions

Freqtrade's api_server default port may collide with existing services. On this server:
- 8090: Hermes FA docs
- 8091: custom trading-bot Flask panel
- 8092: freqtrade api_server (used to avoid collision)
Always `ss -tlnp | grep <port>` before binding.
