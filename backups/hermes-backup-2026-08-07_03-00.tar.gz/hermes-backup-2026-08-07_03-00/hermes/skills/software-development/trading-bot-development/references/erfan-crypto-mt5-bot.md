# Erfan Trading Bot — concrete project reference (Aug 2026)

Built for user @er_saz (Erfan) on 45.38.249.235. Paper-test phase: 1 month, then
user decides on live funds. Paper mode default; live only after explicit approval.

## Layout at /opt/trading-bot

```
bot.py                  # TradingBot class: connect → run_once loop → start()
config.json             # symbol, timeframe, mode, exchange, telegram, supabase, strategy, backtest
strategy/               # EMA9/21/50, RSI(14) 40/60, BB(20,2), ADX(14,≥20), MACD(12,26,9), Donchian(20)
adapters/crypto_adapter.py  # ccxt.mexc() — fetch_ohlcv, ticker; testnet flag
backtest/backtester.py  # spread 0.05% / slippage 0.02% / commission 0.0; SL 1.5% / TP 3% / trailing 0.5%
telegram/reporter.py    # TelegramReporter: send, notify_signal, notify_close, notify_stats,
                        # start_polling(getUpdates+offset), /start /stats /status /pos /backtest
web/                    # Flask dashboard on :8091
mt5/ErfanTradingBot.mq5 # MT5 EA mirroring the same strategy params
```

- State: `data/state.json` (position + trade history) — survives restarts.
- systemd: `trading-bot.service`, WorkingDirectory=/opt/trading-bot. Logs: `journalctl -u trading-bot`.

## config.json keys

`symbol: BTC/USDT`, `timeframe: 1h`, `mode: paper`, `exchange: mexc`,
`interval_sec: 300`, `trade_qty: 0.001`, telegram `{enabled, bot_token, chat_id}`,
supabase `{enabled, host, db, user, password, url}`.

## Exchange reachability from this server (Iran IP 45.38.249.235)

| Exchange | Reachable | Notes |
|---|---|---|
| MEXC | ✅ | used for live data + paper |
| OKX | ✅ | fallback |
| Binance | ❌ | region-blocked |
| Bybit | ❌ | region-blocked |

MEXC public klines via ccxt returned only ~500 recent candles per call — enough
for smoke backtests, not full-year runs.

## Supabase (project cqlqojqeohoeomfccqlo)

- psql: `postgresql://postgres:<pw>@db.cqlqojqeohoeomfccqlo.supabase.co:5432/postgres`
- Tables: `trades`, `bot_stats`, `bot_config` (all `CREATE TABLE IF NOT EXISTS`,
  grants to postgres). Sync via psycopg2 in `bot.sync_supabase()` with
  `INSERT ... ON CONFLICT DO NOTHING`.
- REST root probe with `sb_publishable_` key → 401 = normal; verify with psql.

## Telegram

- Bot: @ERSAZTRADERBOT (token in config.json). Chat: 675366769.
- Startup greeting 400 `chat not found` until user /starts the bot.
- `telegram/` local dir shadows installed `telegram` package → load reporter via
  `importlib.util.spec_from_file_location("tg_reporter", ".../telegram/reporter.py")`.

## Backtest result (BTC/USDT 1h, ~500 candles)

~56% win rate, profit factor ~1.93 — plausible, no lookahead. Sizing bug seen
earlier (zero equity) traced to position-size math (risk % × equity).

## Web panel

:8091 (8090 was taken by Hermes FA docs at /opt/hermes-agent-fa — always
`ss -tlnp | grep <port>` before binding).
