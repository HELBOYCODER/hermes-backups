# Profit protection (سیو سود) — layered stop-ratchet + testing recipe

Verified 2026-08 on /opt/trading-bot executor.py. User requirement (Erfan): "come
out when profit is enough to save" — never give back a good winner.

## The four layers (all in the executor's `_check_position()`)

Runs every cycle while a position is open (executor does NOT open new trades
while one is open). Order of checks:

1. Hard cap `max_profit_target` (0 = off) → close `PROFIT_TARGET`
2. Original TP hit → close `TP`
3. Original SL OR ratcheted `current_sl` hit → close `SL`
4. **Breakeven:** profit ≥ `breakeven_pct` (0.8) → `current_sl = entry` (no loss possible)
5. **Profit lock:** every `lock_step_pct` (1.0) of profit, ratchet:
   `locked = level*step - lock_keep_pct` (0.5); long: `SL = entry*(1+locked/100)`,
   short: `SL = entry*(1-locked/100)`
6. **Trailing:** profit ≥ `trail_after_pct` (2.0) →
   long: `SL = price*(1 - trail_dist_pct/100)`, short: `SL = price*(1 + trail_dist_pct/100)`

## config.json block

```json
"profit_protect": {
  "breakeven_pct": 0.8,
  "lock_step_pct": 1.0,
  "lock_keep_pct": 0.5,
  "trail_after_pct": 2.0,
  "trail_dist_pct": 1.2,
  "max_profit_target": 0
}
```

## Trade-state fields the ratchet needs

`best_price`, `current_sl` (the moving stop — original `sl` stays as disaster
floor), `max_profit`, `current_profit` (updated each check, persisted).

## Correctness rules

- Compare price against BOTH `sl` and `current_sl`; on short side the SL check
  is `price >= stop`, long is `price <= stop`.
- Ratchet only in the profitable direction (long `new_sl > cur`; short `new_sl < cur`)
  or the stop walks backwards.
- Telegram on each kick-in: `🛡️ Breakeven`, `🔒 Profit Locked` — user sees protection live.
- Re-entry dedupe: `last_signal_key = f"{symbol}_{signal}"`; skip signal if already traded.
- Profit pct: long `(price-entry)/entry*100`, short `(entry-price)/entry*100`.

## Testing without a live market

`_check_position()` pulls the live ticker, so direct calls see nothing.
Monkeypatch the adapter with a scripted price:

```python
class FakeAdapter:
    price = 0
    def get_ticker(self):
        return {"last": FakeAdapter.price}
ex.adapter = FakeAdapter()

pos = {"symbol": "BTC/USDT", "side": "long", "entry": 64000, "status": "open",
       "sl": 63000, "tp": 65900, "best_price": 64000, "current_sl": 63000,
       "max_profit": 0}
ex.state["position"] = pos

for p in [64200, 64600, 65000, 65300, 64100]:  # walk: 0.3% → 0.94% → 1.56% → 2.03% → pullback
    FakeAdapter.price = p
    ex._check_position()
    pos = ex.state.get("position")  # None after close → profit was locked
```

Expected at 64600: SL ratchets to 64000 (breakeven); at 65000: SL → 64320
(lock level 1 = +0.5%); at 65300: trailing SL → 64960; at 64100: closed with
profit locked (entry was 64000, closed above it). Run the mirrored walk for
shorts (falling prices, SL ratchets DOWN below entry). Both directions verified.

## Deployed instance

/opt/trading-bot/executor.py (`SignalExecutor`, mode=paper), systemd
`trading-executor.service` (interval 300s), state in data/state.json.
