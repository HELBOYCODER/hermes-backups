---
name: trading-bot-development
description: "Use when building automated trading bots (crypto/MT5)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [trading, bot, ccxt, backtest, metatrader, mt5, mql5, telegram]
  related_skills: [telegram-bot-python, supabase-backend, self-hosted-services]
---

# Trading Bot Development

Build automated trading bots with a shared strategy core, thin exchange adapters, honest backtesting, a web panel, and a Telegram command layer. Covers crypto (CCXT) and MetaTrader 5 (MQL5 EA) targets, paper mode first, live only after user-approved paper results.

## Architecture (proven shape)

One strategy core, multiple adapters — never fork the strategy per target:

```
strategy/          # indicator logic (EMA/RSI/BB/ADX/MACD/Donchian) + confidence scoring
adapters/          # crypto_adapter.py (CCXT), paper adapter, MT5 EA equivalent
backtest/          # backtester.py (honest metrics, spread/slippage/commission)
telegram/          # reporter.py: signal/close notifications + /commands polling
web/               # dashboard panel (Flask) for state + stats
bot.py             # main loop: fetch → signal → enter/exit → persist → notify
config.json        # symbol, timeframe, mode(paper/live), exchange, telegram, supabase
```

- `run_once()` cycles: fetch OHLCV → strategy → open/close position → update state file → sync DB → notify Telegram.
- State lives in a JSON file (`state.json`) so the bot survives restarts; DB (Supabase/Postgres) mirrors trades + stats.
- Default `mode: paper`; live trading only after the user explicitly approves post-paper-test.

## Backtesting honesty

- Model **spread %, slippage %, commission %** — defaults 0.05/0.02/0.0 make paper results believable.
- Report win rate, profit factor, expectancy, max drawdown, total return, Sharpe. Empty equity or zero-size positions usually mean a sizing bug — check position-size math (risk % × equity) before trusting a backtest run.
- Pull real data from the target exchange for the backtest (not synthetic). Watch for **API candle limits**: e.g. MEXC public klines via ccxt returned only ~500 recent candles — enough for a smoke test, not a full-year backtest; fetch more / use a lower timeframe or note the limitation.
- Test on 1h BTC/USDT; expect modest, plausible results. Sky-high win rates in a first backtest = look for lookahead/sizing bugs.
- When reporting results to the user, ALWAYS show both sides: wins AND losses, gross profit AND gross loss, win rate, net PnL. This user explicitly corrected twice: asking "how much profit" still expects the loss figure side by side ("و چقدر ضرر"). A profit-only report reads as dishonest.

## Live-data simulation (validate without waiting for the market)

To show the user REAL closed trades + PnL now (live prices move too slowly for a demo): walk real historical candles from the exchange through the executor's own logic and record every open/close:
- Fetch N candles (e.g. 500 × 1h) per symbol; compute signals on the rolling window with the same strategy engine as live.
- Open on signal; each bar manage the position exactly like `_check_position()`: SL/TP + profit-protection ratchet + strategy-reverse exit.
- Record `entry/exit/pnl_pct/close_reason` per trade, then run the normal PnL report (wins, losses, win rate, gross profit/loss, net) and push to Telegram.
- Verified: 129 closed trades across 3 real MEXC symbols, 48.8% win rate, +64% net — believable, and because it reuses the executor exit logic the numbers match what the live bot would do (minus spread/slippage).
- Keep as `simulate_live.py` in the project; rerun after any strategy change as a fast sanity check.

## Exchange reachability (region-dependent — verify, don't assume)

From an Iran-hosted server (this user): **MEXC and OKX work; Binance and Bybit are region-blocked** (Binance: 451/blocked). Always probe reachability with a tiny ccxt call before building on an exchange:

```python
import ccxt
ex = ccxt.mexc()
print(ex.fetch_ticker("BTC/USDT"))
```

## Telegram integration

Reuse the `telegram-bot-python` skill: same token verification, polling (`getUpdates` + offset), and command pattern. Implement `/start /stats /status /pos /backtest`. Startup greeting will 400 `chat not found` until the user /starts the bot. If the project has a local `telegram/` package dir, load the reporter via `importlib.util.spec_from_file_location` (module-shadowing pitfall — see telegram-bot-python skill).

## Persistence via Supabase

Three tables cover it: `trades` (time, side, entry, exit, pnl_pct, confidence, exchange, mode, status, close_reason), `bot_stats`, `bot_config`. Connect with `psycopg2` straight to `db.<ref>.supabase.co:5432` (see `supabase-backend` skill — REST root 401 is normal). Idempotent `CREATE TABLE IF NOT EXISTS`; `INSERT ... ON CONFLICT DO NOTHING` for sync.

## Market scanner (all-symbol sweep)

For "watch the whole market, find the best setups" asks:
- Scan every symbol the exchange lists (MEXC: ~600 USDT pairs) on a cadence (systemd `trading-scanner.service`, hourly), score each symbol (trend + candlestick pattern + S/R proximity + confidence), report top N picks to Telegram.
- Candlestick patterns (hammer, engulfing, stars) + auto-detected support/resistance (clustered swing highs/lows) feed the score; S/R proximity grades entry quality.
- The scanner is a batch mode over the same strategy core — not a separate strategy. Reuse `run_once()` signal logic.
- **Pitfall:** dead/zero-price coins break S/R distance math (`dist = abs(cur - lvl) / cur * 100` → `RuntimeWarning: invalid value` when `cur == 0`). Guard `if cur == 0: continue` in the distance loop.
- **Dead-coin filters (must-have in `analyze()`):** skip coins priced `< 0.0001` AND coins with `< 0.1%` price movement over the last 50 candles (`abs(price_now / price_50ago - 1) < 0.001` → skip). Without this the scanner picks static micro-caps (real case: NEX/USDT frozen at 1.49e-06) → executor opens a paper position that never moves → never hits SL/TP → demo run stuck forever with an open position.
- Report via the same Telegram reporter — the scan message is just another report type.

## Single-pair real-time paper trader (minute timeframe)

For "trade ONE pair live on a minute timeframe with fake money" asks, use a slim single-pair loop instead of the scanner executor:

- `minute_trader.py`: `fetch_df(120 × 1m)` → strategy signal → open on signal (S/R-based SL/TP, min 0.8%/1.5%) → per-cycle `_check_position()` with the profit-protection ratchet (breakeven → lock steps → trailing) → persist `state_minute.json` → notify Telegram. Runs as `trading-minute.service`, cycle = timeframe (60s).
- Minute-frame params that work: EMA 5/13/34, RSI 7 (35/65), BB 15/2.0, ADX 10 (min 18), MACD 8/17/5, Donchian 10, min_confidence 2. SL 0.8% / TP 1.5%, breakeven at +0.4%, lock step 0.5%, trailing after +0.8%.
- **Don't run the scanner-executor service at the same time** — both paper-trade the same state and double-open positions; disable the other service when switching modes.
- BTC/USDT is the default for minute trading (most liquid, tightest 1m spreads).
- Signal often sits at 0 for many cycles — normal, it waits for a setup. Verify the loop via `journalctl` `OPEN`/`CLOSE` lines, not by expecting constant activity.

## Ready-made broker bots (user asks "what exists out there")

- **freqtrade** (~53k⭐) — 30+ exchanges incl. MEXC/OKX (Iran-reachable), backtest + hyperopt auto-optimization, web UI + Telegram, ready strategies. Best take-and-run candidate.
- **hummingbot** (~19k⭐) — market-making specialization, 14+ connectors.
- **jesse** (~8k⭐) — research-first architecture, CCXT-backed.
- **OctoBot** — GUI-first, 10+ exchanges.
- Honest framing: no bot guarantees profit; proven path stays demo → testnet → live. Offer hybrid: keep our strategy's signals, use freqtrade for execution on MEXC/OKX. Backtest candidates before recommending — don't promise returns.

### Freqtrade integration (verified setup)

Freqtrade 2026.7 in its own venv at `/opt/freqtrade` (config `config_mexc.json`, strategy `ErfanStrategy.py` in `user_data/strategies/`). Verified flow:

1. **Data before backtest/hyperopt:** `freqtrade download-data --config <cfg> --timeframe 1h --timerange <from>-` (3 months × 1 symbol ≈ 5s).
2. **Hyperopt needs extra deps** the base install lacks — `pip install filelock scikit-learn optuna`. Without them: `ERROR - No module named 'filelock'. Please ensure that the hyperopt dependencies are installed.`
3. **Hyperopt-ready params:** error `The 'buy' space is included into the hyperoptimization but no parameter for this space was found` → every tunable must be `IntParameter(...)` / `DecimalParameter(...)` with `space="buy"`/`space="sell"`, and ALL references in populate_* become `.value` (`self.ema_fast.value`). Import from `freqtrade.strategy`.
4. **Run hyperopt in background** (`--hyperopt-loss SharpeHyperOptLoss --epochs 40`) — minutes long, exceeds foreground tool cap.
5. **Backtest divergence is expected:** the same strategy that backtested +64% in our custom engine (STRATEGY_REVERSE exits) scored ~0% in freqtrade's first backtest because freqtrade uses its own exit logic (minimal_roi, exit_profit_only). Numbers never transfer between engines — re-tune per engine with hyperopt, don't panic at the first freqtrade result.
6. `dry_run: true` = paper mode; api_server needs a `username` (mandatory key).
7. **Live dry-run deploy (always-on):** `freqtrade trade --config <cfg> --strategy <S>` runs the bot — dry_run = paper money but REAL market data and live fills. Wrap in systemd: `WorkingDirectory=/opt/freqtrade`, `ExecStart=/opt/freqtrade-venv/bin/freqtrade trade --config ... --strategy ...`, `Restart=always`, `RestartSec=15`. Verify via the API server (`curl -s -u <user>:<pass> http://localhost:<port>/api/v1/status` → JSON list of open trades with `open_rate`/`stake_amount`) and `journalctl -u <unit>` for `Wallets synced.` + first `entry_fill`. A live position opens within minutes on a 1h timeframe — if nothing opens in ~15 min, check the pairlist/log, don't assume silence = working. Freqtrade's API server is a separate port from the bot: on this server 8090/8091 were already taken (Hermes FA docs, trading panel) → freqtrade API landed on 8092.

Full recipe + config skeleton: `references/freqtrade-setup.md`.

## MetaTrader 5 execution paths

- **MT5 bridge on Linux is a dead end** — the docker MT5 bridges (MT5Bridge etc.) need Windows containers; MetaTrader only runs on Windows. Working architecture on a Linux server: EA compiled into the user's MT5 terminal on Windows + a Python connector (`mt5_connector.py`, `pip install MetaTrader5`) that polls the server's signal API and fires trades. Server = signal source, Windows box = execution.
- **MQL5 web session ≠ trading access.** Cookies `auth`+`sid` from mql5.com authenticate the website profile/account (balance, purchases, community) but never the MT5 terminal. Verify the session via the `auth_logout` link; extract the username from `/en/users/<name>/accounting/*` links. Full verified flow: `references/mql5-web-session-auth.md`.
- MT5 EA: compile the `.mq5` in MetaEditor, export path for the user; the EA mirrors the crypto strategy (same indicator params) so paper results transfer.

## Deployment

- systemd unit (`trading-bot.service`) running `bot.py` with `WorkingDirectory=/opt/<proj>`; journalctl for logs.
- **Check port availability before binding the web panel** — in-session 8090 was already taken by another service (Hermes FA docs); moved panel to 8091. `ss -tlnp | grep <port>` first.
- MT5 EA: compile the `.mq5` in MetaEditor, export path for the user; the EA mirrors the crypto strategy (same indicator params) so paper results transfer.

## Pitfalls

- **Strategy-reverse exit (user requirement):** executor closes an open position when the strategy signal flips to the opposite side (long + sig == -1, short + sig == 1), `close_reason = STRATEGY_REVERSE`, checked BEFORE SL/TP. Trades follow the strategy signal, not just price levels; in ranging markets this dominates the close-reason count with many small wins (self-reversing, never waits for stops).
- `No module named 'telegram.reporter'` at runtime in systemd but fine in a quick test → local `telegram/` dir shadowed by installed `telegram` package; use importlib direct-file load (see telegram-bot-python).
- 400 `chat not found` on startup message → user must /start the bot first.
- Supabase REST root 401 with publishable key → normal; verify via psql.
- Don't hardcode the bot token in code shared to GitHub; keep it in config.json + systemd env.
- **`pkill -f "<pattern>"` can kill your own shell:** if the pattern text appears in the compound command's own cmdline (it does — you typed it), pkill -f SIGTERMs the shell running the command → whole thing aborts (exit -15, the systemctl start after it never runs). First freqtrade deploy died exactly this way (`pkill -f "freqtrade trade"; systemctl start ...`). Use the bracket trick `pkill -f "[f]reqtrade trade"`, or better: `systemctl stop <unit>` for managed services, and keep stop/start in separate tool calls.

## References

- `references/erfan-crypto-mt5-bot.md` — concrete project layout at /opt/trading-bot, config keys, exchange reachability matrix, Supabase host/tables, MT5 EA notes.
- `references/mql5-web-session-auth.md` — verified MQL5 website cookie auth (auth+sid), login-state check via auth_logout link, username extraction, scope limits.
- `references/freqtrade-setup.md` — Freqtrade hyperopt-ready setup: deps, IntParameter conversion recipe, backtest divergence warning, config skeleton.
