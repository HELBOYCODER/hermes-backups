# Worked example: HaveAll bot + Supabase (6-table schema, REST shim)

HaveAll is a Telegram bot that aggregates VPN/proxy configs (VLESS/VMess/Trojan/SS/Hysteria/TUIC) into Supabase tables. This is the full debug path that produced the patterns in SKILL.md.

## Symptom chain (in order seen)

1. `Portal error. Verify database configuration.` — app's DB layer couldn't reach tables.
2. `Failed to generate configs: Client error '404 Not Found' for url 'https://<ref>.supabase.co/rest/v1/configs?select=%2A&order=created_at.desc'` — PostgREST 404 = **tables don't exist**, not a key problem.
3. New-format keys (`sb_publishable_...` / `sb_secret_...`) broke `supabase-py` auth entirely — so the REST-404 diagnosis had to be done with `curl` + the secret key, not the Python client.

## What worked

- **Diagnosis:** `curl -H "apikey: <sb_secret_...>" -H "Authorization: Bearer <sb_secret_...>" https://<ref>.supabase.co/rest/v1/configs` → 404 confirmed missing table.
- **Schema bootstrap:** connected with the PostgreSQL connection string
  `postgresql://postgres:<pw>@db.<ref>.supabase.co:5432/postgres`
  and ran `CREATE TABLE IF NOT EXISTS` statements. Six tables were created this way:
  `configs`, `proxies` (MTProto), plus monitor/log tables. All idempotent.
- **Client shim:** the bot's code expected `supabase-py` objects; replaced with a thin `requests`-based client exposing the same method names (`select`, `insert`, `order`) so the rest of the codebase didn't change.

## End state

- 1,659 configs / 54 proxies in the tables; scraper refresh every 30 min; bot polling on Telegram.
- Supabase dashboard SQL Editor works as a manual fallback when psql is unavailable (no server-side IP allowlisting needed).
