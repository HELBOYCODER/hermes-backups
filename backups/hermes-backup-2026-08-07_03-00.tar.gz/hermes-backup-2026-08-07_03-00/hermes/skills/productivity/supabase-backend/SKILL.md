---
name: supabase-backend
description: "Use when a project uses Supabase as its backend."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [supabase, postgres, rest, database, backend, anon-key, service-key]
  related_skills: [telegram-bot-python]
---

# Supabase as a backend

Connect, authenticate, and bootstrap Supabase projects from server-side code (Telegram bots, scrapers, APIs).

## Key formats — know which is which

Users hand over tokens in several formats; map them before wiring anything:

| Prefix / shape | What it is | Usable from a server script? |
|---|---|---|
| `sbp_...` | Management API token (dashboard/API only) | No — REST data API rejects it |
| `sb_publishable_...` | New-style publishable key | With new SDKs only; older clients fail |
| `sb_secret_...` | New-style secret key | Works as `apikey`/`Authorization: Bearer` against the REST API |
| `eyJhbGci...` (JWT) | Old-style `anon` / `service_role` key | Yes — classic choice |

## Direct REST API instead of client libraries (verified pattern)

New-format keys (`sb_publishable_`/`sb_secret_`) break older Python clients (e.g. `supabase-py`): auth handshake fails, then everything downstream errors confusingly. When the user has new-format keys, skip the library and talk to the REST API directly with `requests`:

```python
BASE = "https://<project-ref>.supabase.co/rest/v1"
H = {
    "apikey": SECRET_OR_ANON_KEY,                 # sb_secret_... or eyJ... both work
    "Authorization": f"Bearer {SECRET_OR_ANON_KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=representation",
}
r = requests.get(f"{BASE}/configs", params={"select": "*", "order": "created_at.desc"}, headers=H)
```

Queries: `params={"select": "*", "order": "col.desc"}`. Inserts: `requests.post(url, json=[{...}], headers=H)`. This also dodges version churn — the REST API is the stable surface.

## REST 404 = tables missing → bootstrap via PostgreSQL

`404 Not Found` on `/rest/v1/<table>` (with a *valid* key) means **the table does not exist** — Supabase's PostgREST returns 404, not a friendly error. Symptom chain seen in the wild: "Portal error. Verify database configuration." then `Failed to generate configs: Client error '404 Not Found' for url '.../rest/v1/configs'`.

Fix: create the schema directly through the project's PostgreSQL connection string:

```
postgresql://postgres:<PASSWORD>@db.<project-ref>.supabase.co:5432/postgres
```

- Requires the server's IP to be allowlisted in Supabase → **Database → Connection → IP restrictions**, else `psql` hangs/times out.
- Run with `psql "<connstring>" -f schema.sql` using `CREATE TABLE IF NOT EXISTS ...` so it's idempotent. The Supabase dashboard SQL Editor is the manual alternative — always offer the connection-string path first when you have shell access.

## Pitfalls

- **401 on the REST root probe is normal**: `GET https://<ref>.supabase.co/rest/v1/` with a new-style `sb_publishable_` key returns 401 even on a healthy project — the bare root has no anonymous access. Verify connectivity with `psql` against `db.<ref>.supabase.co:5432` (direct Postgres connected in-session without extra IP allowlisting) or a real table query (`/rest/v1/<table>?select=*&limit=1`), never the bare root.
- **Do not guess which key is which** — when the user pastes a `sbp_...` or `sb_...` token, state plainly it is a management/new-style key and ask for the anon JWT or use the secret via REST. Burning attempts on the wrong key wasted an hour in a past session.
- **User confusion is common**: they paste dashboard URLs, docs links, or `postgresql://` connection strings when asked for a URL/key. Ask for exactly one thing at a time, show the expected shape (`https://xxxx.supabase.co`, `eyJ...`).
- **Keep stored data minimal for bots**: logs/state only, never file content — see `telegram-bot-python` skill's no-persistence rule for this user.

## References

- `references/haveall-bot-supabase.md` — worked example: 6-table schema, REST client shim for a bot that expected supabase-py.
