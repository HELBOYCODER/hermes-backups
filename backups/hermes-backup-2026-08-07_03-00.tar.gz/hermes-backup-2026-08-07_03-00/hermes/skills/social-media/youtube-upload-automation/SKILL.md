---
name: youtube-upload-automation
description: Use when uploading videos to YouTube with SEO metadata.
---

# YouTube Upload Automation (official API v3)

## When to use
- User wants to upload videos/music beats to their YouTube channel
- Scheduled/recurring uploads (e.g. weekly beats) with SEO-optimized titles, descriptions, tags

## Setup
- Libs: `pip install google-api-python-client google-auth-oauthlib google-auth-httplib2` (system pip w/ --break-system-packages ok)
- This server: `/opt/youtube-uploader/` — `upload.py` (single upload), `weekly_upload.py` (watch-folder), `client_secret.json`, `token.json`, `beats/` (inbox), `archive/` (processed), `upload_log.jsonl`
- Google Cloud: enable **YouTube Data API v3** → OAuth **Desktop app** client → download `client_secret.json` into `/opt/youtube-uploader/`

## OAuth flow (headless-server aware)
1. `InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS, SCOPES)` — scopes: `youtube.upload` + `youtube`
2. On a headless server `flow.run_local_server(port=0)` cannot open a browser — the flow needs to run where the user has a browser, or use `flow.run_console()` / print `flow.authorization_url()` and have the user paste the code back.
3. Persist: `creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)`; refresh with `creds.refresh(Request())` when expired (refresh_token persists).
4. Re-auth: delete `token.json` and rerun.

## Upload pattern (resumable, chunked)
```python
service = build("youtube", "v3", credentials=creds)
media = MediaFileUpload(path, chunksize=8 * 1024 * 1024, resumable=True)
req = service.videos().insert(part="snippet,status", body=body, media_body=media)
status, resp = None, None
while resp is None:
    status, resp = req.next_chunk()   # status.progress() → percent
# resp["id"] → https://youtu.be/<id>
```

## SEO metadata limits (API-enforced)
- `snippet.title` ≤ **95** chars
- `snippet.description` ≤ **4950** chars
- `snippet.tags` ≤ **30** tags (each ≤100 chars)
- `snippet.categoryId` "10" = Music; `status.privacyStatus` public/unlisted/private
- `status.selfDeclaredMadeForKids: False`
Full beat template: `references/seo-metadata.md`

## Watch-folder weekly pattern (no-LLM cron friendly)
`beats/*.mp4|mov|mkv|webm` → upload each with generated SEO metadata → move to `archive/` (prevents duplicate uploads on rerun) → sleep 30s between uploads. Drives fine from a plain cron line; no agent needed.

## Pitfalls
- API quota: uploads cost ~1600 units of the 10k/day default — a few uploads/day is safe, do not loop aggressively.
- Never re-upload the same file: archive-after-upload is the guard.
- `token.json` binds to scopes+project; changing client_secret requires fresh auth.
- Verify upload by printing `https://youtu.be/<video_id>` and appending to `upload_log.jsonl` — don't trust the API call silently.

## Files
- `templates/upload.py` — known-good uploader (CLI: file + --title/--description/--tags/--privacy/--category, --auth to re-auth)
- `references/seo-metadata.md` — beat title/desc/tags template (Trap producer channel)
