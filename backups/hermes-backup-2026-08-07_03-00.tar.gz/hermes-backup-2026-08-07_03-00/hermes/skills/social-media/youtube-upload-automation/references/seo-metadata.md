# SEO metadata template — weekly Trap beat uploads (Erfan's channel)

Generated per beat from filename stem (e.g. `beat1.mp4` → `Beat1`).

## Title (≤95 chars)
```
🎧 {Beat Name} | Trap Beat 2026 | Free Beat
```

## Description (≤4950 chars)
```
🎧 {Beat Name} — new original Trap beat by Erfan Torabi

🔥 FREE DOWNLOAD / USE: Non-commercial use with credit.
🎚️ Mix & Master: Erfan Torabi
📩 Commercial use & collaboration: DM @er_saz on Instagram

🎵 New beats uploaded every week — subscribe & hit the bell 🔔

#trap #trapbeat #musicproducer #beatmaker #hiphop #musicproduction
#flstudio #mixing #mastering #typebeat #persianmusic #newbeat
#producer #beat #banger #freebeat #trending #explore
```

## Tags (≤30)
```
trap,trap beat,music producer,beatmaker,hip hop,music production,fl studio,
mixing,mastering,type beat,persian music,new beat,producer,beat,banger,free beat
```

## Fields
- `categoryId`: "10" (Music)
- `privacyStatus`: "public" (or unlisted for premiere scheduling)
- `selfDeclaredMadeForKids`: False

## Hook logic (why it pulls views)
- Year in title ("2026") → freshness signal
- "Free Beat" → search intent for beat buyers/rappers
- Milestone-style CTA + subscribe/bell ask in description
- Hashtag mix: broad (#trap #hiphop) + niche (#typebeat #beatmaker) + Farsi (#persianmusic) + platform (#trending #explore)
