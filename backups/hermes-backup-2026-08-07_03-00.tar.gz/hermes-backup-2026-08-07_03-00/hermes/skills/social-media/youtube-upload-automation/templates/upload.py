#!/usr/bin/env python3
"""YouTube uploader — resumable, SEO metadata, CLI. Deployed: /opt/youtube-uploader/upload.py"""
import sys
import time
import json
from pathlib import Path
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

BASE = Path("/opt/youtube-uploader"); BASE.mkdir(parents=True, exist_ok=True)
CLIENT_SECRETS = BASE / "client_secret.json"
TOKEN_FILE = BASE / "token.json"
SCOPES = ["https://www.googleapis.com/auth/youtube.upload",
          "https://www.googleapis.com/auth/youtube"]

def get_service():
    creds = None
    if TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not CLIENT_SECRETS.exists():
                print("❌ client_secret.json not found"); sys.exit(1)
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS, SCOPES)
            creds = flow.run_local_server(port=0)   # headless: use run_console() instead
        TOKEN_FILE.write_text(creds.to_json())
    return build("youtube", "v3", credentials=creds)

def make_metadata(title, description, tags, category="10", privacy="public"):
    return {
        "snippet": {
            "title": title[:95],
            "description": description[:4950],
            "tags": [t.strip() for t in tags if t.strip()][:30],
            "categoryId": category,
        },
        "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False},
    }

def upload(file_path, title, description, tags, category="10", privacy="public"):
    service = get_service()
    body = make_metadata(title, description, tags, category, privacy)
    media = MediaFileUpload(file_path, chunksize=8 * 1024 * 1024, resumable=True)
    req = service.videos().insert(part="snippet,status", body=body, media_body=media)
    print(f"📤 Uploading {Path(file_path).name}...")
    resp = None
    while resp is None:
        status, resp = req.next_chunk()
        if status:
            print(f"   {int(status.progress()*100)}%", end="\r", flush=True)
    vid = resp["id"]
    print(f"\n✅ https://youtu.be/{vid}")
    with open(BASE / "upload_log.jsonl", "a") as f:
        f.write(json.dumps({"time": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "file": file_path, "video_id": vid, "title": body["snippet"]["title"]}) + "\n")
    return vid
