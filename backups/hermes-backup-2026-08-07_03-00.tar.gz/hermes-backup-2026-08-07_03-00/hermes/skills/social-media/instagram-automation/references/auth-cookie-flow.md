# Instagram sessionid Cookie Auth Flow (working code)

Proven pattern from real session (2026-08): password login failed with `BadPassword` from
datacenter IP; sessionid cookie flow succeeded. Deployed at `/opt/instagram-cli/auth/`.

## Layout
```
/opt/instagram-cli/
├── ig.py                 # CLI wrapper (stats, posts, stories...)
├── auth/
│   ├── index.html        # paste-sessionid page (RTL Persian)
│   └── server.py         # HTTP server, saves cookie
└── sessions/
    ├── sessionid.txt     # raw cookie (written by auth server)
    └── session.pkl       # instagrapi settings dump (post-login)
```

## 1. Auth server (server.py essentials)
```python
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

SESSION_FILE = Path("/opt/instagram-cli/sessions/sessionid.txt")
AUTH_TOKEN = "ersaz2026"   # static token; page sends it alongside the cookie

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/index.html"):
            html = Path("/opt/instagram-cli/auth/index.html").read_text()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers(); self.wfile.write(html.encode())
    def do_POST(self):
        if self.path == "/auth":
            data = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
            if data.get("token") != AUTH_TOKEN: self._json({"ok": False, "error": "bad token"}); return
            SESSION_FILE.write_text(data["sessionid"].strip())
            self._json({"ok": True})

HTTPServer(("0.0.0.0", 8082), Handler).serve_forever()
```
Run: `AUTH_TOKEN=ersaz2026 python3 auth/server.py` (or systemd). Page at `http://IP:8082`.

## 2. Client login (no password)
```python
from instagrapi import Client
cl = Client()
cl.delay_range = [2, 4]
cl.login_by_sessionid(Path("sessions/sessionid.txt").read_text().strip())
cl.dump_settings("sessions/session.pkl")
```
Later sessions: `cl.load_settings("sessions/session.pkl")` — no login round-trip at all.

## 3. Cookie extraction steps for the user (put on the auth page)
1. Open instagram.com in a normal browser, log in.
2. F12 → Application tab → Cookies → `instagram.com` → copy value of `sessionid`.
3. Paste into auth page → POST → server saves it.

## Diagnostic ladder when login fails
| Error | Meaning | Action |
|---|---|---|
| `BadPassword` (from server IP) | IP/fingerprint/context rejected, password may be fine | Try Tor proxy to confirm |
| "can't find an account with X" (via Tor) | wrong login identifier | Get exact handle/email/phone |
| 401 on POST | session expired | Re-fetch fresh sessionid from browser |
| Same error via Tor | account-level block | Try second account to isolate |

## Gotchas hit in the field
- `from instagrapi.mixins.device import Device` → ModuleNotFoundError (2.18.x). `set_device()` takes a plain dict.
- Tor (`socks5h://127.0.0.1:9050`) changes error text — that's the diagnostic trick, not necessarily the fix; session tokens don't survive IP change.
- auth page must send `token` with every POST or it silently drops cookies — wire it into the JS body.
