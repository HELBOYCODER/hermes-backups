# Verified SEO content — music producer (Trap) page

Applied successfully to @er_saz (instagrapi 2.18.x, Aug 2026). All edits went through with
`delay_range=[4,8]` + 20s sleep between posts.

## Bio (≤150 chars, `\n` line breaks)
```
🎧 Trap & Hip-Hop Music Producer
🎛️ Mix & Master | Beatmaker
🇮🇷 Erfan Torabi
🔥 New beats every week
📩 For collaboration: DM
```

## Post 1 — hook + milestone CTA + offer list + hashtags (image)
```
🎧 Trap Music Producer | Erfan

این یه قطعهٔ جدید از ساخته‌هامه — ترپ با انرژی خام 🖤
اگر این پست به ۱۰۰۰ ویو برسه، نسخهٔ کامل رو منتشر می‌کنم! 🔥

🎵 چیزهایی که توی این پیج پیدا می‌کنی:
• بیت‌های ترپ و هیپ‌هاپ اختصاصی
• میکس و مسترینگ حرفه‌ای
• پشت‌صحنهٔ تولید موسیقی
• کالاب و همکاری با آرتیست‌ها

🎧 پشتیبانی کن تا قطعه‌های بعدی رو بسازم ⬇️
💬 نظر بده — دیدگاهت برام مهمه!

#trap #trapmusic #musicproducer #beatmaker #hiphop #persianmusic #iranianproducer #musicproduction #flstudio #ableton #mixing #mastering #newbeat #trapbeat #producerlife #beatmaking #studiolife #undergroundmusic #persianrap #trendingaudio
```

## Post 2 — studio/behind-scenes (image)
```
🎵 Erfan Torabi — Music Producer

یه نگاه به استودیو و فضای کاری من 👇
همهٔ این صداها از صفر ساخته شدن؛ از ایده تا خروجی نهایی.

🎛️ روی این پیج:
• بیت و ملودی اختصاصی
• میکس و مسترینگ
• همکاری با خواننده‌ها

برای کالاب یا سفارش بیت، دایرکت بدید 💬
پیج رو به دوستات معرفی کن 🙏

#musicproducer #producer #beatmaker #trapmusic #hiphopbeats #musicproduction #flstudio #ableton #mixing #mastering #beatsforsale #typebeat #persianmusic #irantrap #studiolife #audiomixing #sounddesign #beatmaking #musicstudio #producerlife
```

## Post 3 — reel / new beat teaser (video, virality-focused)
```
🎧 New Trap Beat 2026 — Full Version Coming Soon! 🔥

نسخهٔ جدید میکس — قطعهٔ اختصاصی خودم 🖤
«اگه این پست به ۱۰٬۰۰۰ ویو برسه، نسخهٔ کامل منتشر می‌شه» — بریم؟ 🚀

👂 این قطعه رو با هدفون گوش بدید تا جزئیات رو بشنوید!
🎚️ میکس و مستر: Erfan Torabi

ساخته شده با ❤️ و ساعت‌ها تلاش در استودیو
حمایت‌تون = قطعه‌های بیشتر ⬇️🔥

#reels #trap #trapbeat #musicproducer #newmusic #trending #viral #beatmaker #hiphop #musicproduction #flstudio #persianmusic #iranianproducer #mixing #mastering #typebeat #banger #producer #beat #explorepage #reelsinstagram #fyp
```

## Reusable recipe (any new post)
1. Line 1: `[emoji] [post type] | [positioning]` — e.g. `🎧 New Trap Beat 2026 — Full Version Coming Soon! 🔥`
2. 1-2 Farsi lines with a **milestone CTA** (`اگر این پست به N ویو برسه، نسخهٔ کامل منتشر میشه`)
3. Bulleted value list (services/niche)
4. Engagement CTA (نظر بده / دایرکت بدید / پیج رو معرفی کن)
5. 20 hashtags: 5 broad (`#trap #hiphop #musicproducer`), 5 niche (`#typebeat #beatmaker`), 5 Farsi (`#persianmusic #irantrap`), 5 virality (`#fyp #explorepage #viral #trending #reelsinstagram`)
