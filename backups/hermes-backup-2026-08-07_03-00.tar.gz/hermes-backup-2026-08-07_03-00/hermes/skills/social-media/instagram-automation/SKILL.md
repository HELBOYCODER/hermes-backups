---
name: instagram-automation
description: Use when user needs Instagram login/automation (instagrapi).
---

# Instagram Automation (instagrapi)

## When to use
- User wants to connect, monitor, or automate their Instagram account (posts, stories, DMs, stats)
- Username/password login fails, or user has no clean password path

## Setup
- Library: `pip install instagrapi` (2.18.x verified)
- This server: `/opt/instagram-cli/` — CLI wrapper (`ig.py`), auth server (`auth/`), sessions dir

## Auth strategy: sessionid cookie, NOT password
Instagram rejects password login from datacenter IPs (`BadPassword` — "can also happen when Instagram rejects the proxy/IP, device fingerprint, or login context") even with correct credentials. Reliable flow:
1. Serve auth page on user's server (port 8082): user logs into instagram.com in their own browser, copies the `sessionid` cookie (F12 → Application → Cookies → instagram.com)
2. Page POSTs cookie to server `/auth` endpoint → server saves to `sessions/sessionid.txt`
3. Python client: `cl.login_by_sessionid(sid)` — no password; session looks like the user's real browser

Full working code: `references/auth-cookie-flow.md`

## Device fingerprint (always set before any login)
```python
cl = Client()
cl.delay_range = [2, 4]
cl.set_device({...})  # real Android device: app_version/android_version/manufacturer/device/model/cpu/dpi/resolution
cl.set_user_agent('Instagram <ver> Android (...)')
cl.login_by_sessionid(sid)
cl.dump_settings('sessions/session.pkl')  # later restore with cl.load_settings()
```

## Pitfalls
- `account_info()` in 2.18.x returns a limited model — reading `follower_count` etc. off it raises AttributeError. Use `cl.user_info(cl.user_id)` instead. Field names are snake_case: `follower_count`, `following_count`, `media_count`, `biography`, `is_verified`, `is_private` (NOT camelCase).
- `BadPassword` ≠ wrong password. Diagnostic: rerun the same login via Tor (`cl.set_proxy('socks5h://127.0.0.1:9050')`). If the error changes (e.g. to "can't find an account"), credentials path is fine and the IP is the blocker.
- "We can't find an account with X" = wrong login identifier. Instagram login handle ≠ display name — ask for exact handle / email / phone.
- Do NOT retry password login repeatedly from a server: burns the account (rate limits, checkpoints).
- Session tokens bind to the IP they were created on; changing proxy invalidates them.
- `set_device()` takes a plain dict — do NOT `from instagrapi.mixins.device import Device` (module doesn't exist in 2.18.x).
- `sessionid` is as sensitive as a password — store only on the user's own server.
- Bulk caption/bio edits trigger flags if hammered: keep `cl.delay_range = [4, 8]` and sleep ≥20s between successive `media_edit` calls; verify each change (re-fetch `user_info` / media) before the next.
- `account_set_biography()` in 2.18.x takes plain text with `\n` breaks (≤150 chars) — verified working.
- `media_edit(pk, caption)` replaces the caption on existing posts (images AND videos/reels) — no re-upload needed. Get pks via `cl.user_medias(cl.user_id, amount=N)`.

## Content editing (bio + captions) — SEO overhaul
User's page is a Trap music producer account (@er_saz) — content strategy below is tuned for music/beat pages:
1. `cl.account_set_biography(bio)` — professional bio: role line, services, country, cadence ("New beats every week"), CTA ("DM for collab"). Persian allowed.
2. `cl.media_edit(pk, caption)` per post. New-caption structure: hook line (post type + value prop) → milestone CTA ("full version drops at N views") → bulleted offer list → engagement CTA (comment/DM) → 20 hashtags (mix: broad `#trap`, niche `#typebeat`, Farsi `#persianmusic`, virality `#fyp #explorepage #trending`).
3. Space edits: sleep 20s between posts; verify via fresh `user_medias` fetch at the end.
Full ready-to-reuse captions + bio: `references/seo-caption-templates.md`

## Files
- `references/auth-cookie-flow.md` — auth server + page + client code, incl. token-wiring fix
- `references/seo-caption-templates.md` — verified bio + 3 post captions (music producer SEO)

## Operations (this server)
- CLI wrapper: `cd /opt/instagram-cli && python3 ig.py <cmd>` — `stats`, `profile`, `followers`, `media`, `search`, `hashtag`, `dm`, `story`; restores session via `cl.load_settings('sessions/session.pkl')`
- Auth server runs as systemd `instagram-session.service` (port 8082, Restart=always) so the user can re-paste a fresh `sessionid` cookie anytime the old one expires
- Session file `sessions/session.pkl` binds to the IP it was created on — do not move servers/proxies without re-auth
