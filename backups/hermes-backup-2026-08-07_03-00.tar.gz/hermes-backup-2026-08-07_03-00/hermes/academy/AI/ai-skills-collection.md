<!-- HERMES ACADEMY LESSON -->
ID: ai-skills-20260805
Title: Installed 12 AI operational skills
Category: AI
Difficulty: Beginner
Created: $(date +%s)
TimeSavedMin: 20.0
HermesSec: 120.0
Summary: Installed 12 system-level AI skills (debugging, analysis, optimization, testing)
Concepts: system prompts, skill management, operational patterns
Related: Hermes skills, prompt engineering

---

# Summary
Installed 12 operational AI skills from Tariux/AI-Skills-Not-Awesome into Hermes skills directory.

# Problem
User wanted ready-made system skills for debugging, analysis, optimization, test-writing.

# Solution
1. Cloned repo
2. Converted each .skill.md to Hermes SKILL.md format (frontmatter + content)
3. Installed into ~/.hermes/skills/ai-skills/

# Technical Explanation
Each .skill.md is a system prompt template. Hermes skills need YAML frontmatter with name/description. The description must be ≤60 chars for the system prompt budget.

# Why This Works
Skills load into context when relevant, enforcing specific reasoning patterns without extra setup.

# Professional Best Practices
- Keep descriptions under 60 chars
- Convert external skill formats to Hermes standard
- Test skills load correctly

# Common Mistakes
- Descriptions too long (rejected by skill system)
- Wrong frontmatter format

# Commands Used
```bash
git clone https://github.com/Tariux/AI-Skills-Not-Awesome
bash /root/scripts/install_ai_skills.sh
```

# Files Modified
- ~/.hermes/skills/ai-skills/*/SKILL.md

# Key Concepts Learned
✔ Hermes skill format
✔ System prompt engineering
✔ Skill conversion

# Difficulty
Beginner

# Time Saved
Estimated manual debugging time: 20 minutes
Hermes solved it in: 120 seconds

# Related Topics
- Hermes skill authoring
- Prompt engineering

# References
- https://github.com/Tariux/AI-Skills-Not-Awesome

# Quiz
1. Why keep skill descriptions under 60 chars?
