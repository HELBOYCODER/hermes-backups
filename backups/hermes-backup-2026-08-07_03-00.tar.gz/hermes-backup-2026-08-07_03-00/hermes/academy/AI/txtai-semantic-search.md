<!-- HERMES ACADEMY LESSON -->
ID: txtai-20260805
Title: txtai semantic search + RAG platform
Category: AI
Difficulty: Intermediate
Created: 1785927567
TimeSavedMin: 40.0
HermesSec: 300.0
Summary: Installed txtai platform for semantic search, embeddings, RAG and agent workflows
Concepts: embeddings, vector database, RAG, semantic search, FAISS
Related: Graphify, vector databases, transformers

---

# Summary
Installed txtai (Python AI platform) with embeddings, vector search (FAISS), RAG retrieval and agent pipeline support.

# Problem
User needed a comprehensive local semantic search + RAG platform in Python.

# Solution
1. pip3 install txtai (pulls torch + faiss-cpu + transformers)
2. Built demo: semantic search, RAG retrieval, agent workflow
3. Used sentence-transformers/all-MiniLM-L6-v2 for embeddings (small, fast, local)

# Technical Explanation
txtai embeds text into vectors using transformer models, indexes them in FAISS (in-memory vector DB), and searches by cosine similarity. RAG combines this retrieval with LLM generation. Agent workflows orchestrate tools.

# Why This Works
Semantic search matches meaning (not keywords) because embeddings capture semantic relationships in vector space.

# Professional Best Practices
- Use small local models (MiniLM-L6-v2) for speed on limited hardware
- content=True stores original text alongside vectors for retrieval
- Index once, search many times

# Common Mistakes
- Using huge models on small servers (RAM issues)
- Forgetting content=True when you need text back from search

# Alternative Solutions
- ChromaDB, Qdrant, Weaviate
- FAISS directly

# Commands Used
```bash
pip3 install --break-system-packages txtai
python3 -c "from txtai.embeddings import Embeddings; ..."
```

# Files Modified
- /opt/txtai-demo/demo.py

# Before vs After
Before:
```
No semantic search capability
```
After:
```
Semantic search + RAG + agents working locally
```

# Key Concepts Learned
✔ embeddings
✔ vector database (FAISS)
✔ semantic search
✔ RAG retrieval

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 40 minutes
Hermes solved it in: 300 seconds

# Related Topics
- Graphify knowledge graphs
- Vector databases

# References
- https://github.com/neuml/txtai

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. What is FAISS?
2. Why use MiniLM-L6-v2?
