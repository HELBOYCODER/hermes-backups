<!-- HERMES ACADEMY LESSON -->
ID: hermes-loop-master-20260805
Title: Installed Hermes Loop Master skill
Category: AI
Difficulty: Intermediate
Created: $(date +%s)
TimeSavedMin: 30.0
HermesSec: 120.0
Summary: Installed disciplined coding loop skill for Hermes Agent
Concepts: spec-first, TDD, verification, code review, handoff
Related: systematic-debugging, test-driven-development, code review

---

# Summary
Installed Hermes Loop Master — a disciplined operating loop skill for multi-step, risky, or long-running coding tasks.

# Problem
User needed structured command execution for coding agents: write code, check bugs, and organize development process.

# Solution
1. Cloned https://github.com/s0heyl/hermes-loop-master
2. Ran official install.sh
3. Installed to ~/.hermes/skills/software-development/hermes-loop-master/

# Technical Explanation
The skill enforces 5 behaviors: spec-first (write execution contract before code), one-slice implementation, verification with real evidence, adversarial diff review, and clean handoff. It has 3 adaptive modes: Tiny (≤8 tool calls), Standard (≤20), Critical (no cap). File-backed task files survive context compression and new sessions.

# Why This Works
Structured loops prevent "looks done" shortcuts by requiring real command output as evidence before declaring success.

# Professional Best Practices
- Use Tiny mode for one-file typos, Standard for normal fixes, Critical for security/production
- File-backed artifacts survive model switches

# Common Mistakes
- Using the full loop for trivial changes (wastes tokens)
- Skipping verification evidence

# Commands Used
```bash
git clone https://github.com/s0heyl/hermes-loop-master
bash /opt/hermes-loop-master/install.sh
```

# Files Modified
- ~/.hermes/skills/software-development/hermes-loop-master/SKILL.md

# Key Concepts Learned
✔ spec-first development
✔ evidence-based verification
✔ adaptive task modes

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 30 minutes
Hermes solved it in: 120 seconds

# Related Topics
- TDD
- Code review workflows

# References
- https://github.com/s0heyl/hermes-loop-master

# Quiz
1. What are the 3 adaptive modes?
