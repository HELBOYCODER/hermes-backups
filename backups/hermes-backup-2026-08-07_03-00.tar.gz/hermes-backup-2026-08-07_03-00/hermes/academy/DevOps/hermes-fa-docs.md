<!-- HERMES ACADEMY LESSON -->
ID: hermes-fa-docs
Title: Persian Hermes docs site (Jekyll)
Category: DevOps
Difficulty: Intermediate
Created: 1785926953
TimeSavedMin: 30
HermesSec: 180.0
Summary: Deployed RTL Persian documentation site for Hermes Agent on port 8090
Concepts: Jekyll, RTL, static sites, Ruby
Related: documentation, static hosting

---

# Summary
Deployed RTL Persian documentation site for Hermes Agent on port 8090

# Problem
User needed the Persian Hermes docs readable on their own server

# Investigation
Diagnosed the environment, checked available tooling and port availability, then applied the standard installation path for the tool.

# Solution
Cloned hermes-agent-fa, installed Ruby/Jekyll, fixed baseurl (was pointing to GitHub Pages), built _site, served with python http.server 8090

# Technical Explanation
Jekyll baseurl must be empty when self-hosting at root; otherwise all links point to the original GitHub Pages URL causing 404s

# Why This Works
Static site serving means zero app dependencies at runtime — just rebuild when docs update

# Professional Best Practices
- Always create systemd services for long-running processes (Restart=always)
- Verify with health checks after deployment
- Keep configs in version control or backups
- Bind to 0.0.0.0 only when public access is intended

# Common Mistakes
- Forgetting to enable services for reboot persistence
- Not testing from the public IP
- Skipping firewall/port checks

# Alternative Solutions
- Docker containers with restart policies
- Reverse proxy (nginx/caddy) in front

# Commands Used
```bash
gem install jekyll webrick; jekyll build; python3 -m http.server 8090 --bind 0.0.0.0
```

# Files Modified
- /opt/hermes-agent-fa/_config.yml
- /opt/hermes-agent-fa/_site/

# Before vs After
Before:
```
Service unavailable on public IP
```
After:
```
Service accessible at http://45.38.249.235:PORT
```

# Key Concepts Learned
Jekyll, RTL, static sites, Ruby

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 30 minutes
Hermes solved it in: 180 seconds

# Related Topics
documentation, static hosting

# References
https://github.com/bookunt3d/hermes-agent-fa

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. How is the service kept alive after reboot?
2. Why bind to 0.0.0.0 for public access?
