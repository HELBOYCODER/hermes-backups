<!-- HERMES ACADEMY LESSON -->
ID: v2raydar-subscriptions
Title: V2RayDAR proxy config aggregator
Category: DevOps
Difficulty: Intermediate
Created: 1785926953
TimeSavedMin: 60
HermesSec: 180.0
Summary: Deployed V2RayDAR on port 27141 serving validated proxy configs
Concepts: V2Ray, proxy validation, sing-box, subscriptions
Related: VPN, proxy tools

---

# Summary
Deployed V2RayDAR on port 27141 serving validated proxy configs

# Problem
User needed a service that finds and validates working VPN configs automatically

# Investigation
Diagnosed the environment, checked available tooling and port availability, then applied the standard installation path for the tool.

# Solution
Ran install.sh (portable mode), enabled sharing.enabled + bind 0.0.0.0 in v2raydar_data/configs.yaml, created v2raydar.service

# Technical Explanation
V2RayDAR fetches subscriptions, probes each config through sing-box, ranks working ones, serves at /subscription (base64) and /mihomo.yaml

# Why This Works
Config lives in v2raydar_data/configs.yaml (not root) — must edit the right file; sharing.enabled exposes it beyond localhost

# Professional Best Practices
- Always create systemd services for long-running processes (Restart=always)
- Verify with health checks after deployment
- Keep configs in version control or backups
- Bind to 0.0.0.0 only when public access is intended

# Common Mistakes
- Forgetting to enable services for reboot persistence
- Not testing from the public IP
- Skipping firewall/port checks

# Alternative Solutions
- Docker containers with restart policies
- Reverse proxy (nginx/caddy) in front

# Commands Used
```bash
cd /root/V2RayDAR && ./v2raydar --no-tui --portable; sed -i 's/bind: 127.0.0.1:27141/bind: 0.0.0.0:27141/' v2raydar_data/configs.yaml
```

# Files Modified
- /root/V2RayDAR/v2raydar_data/configs.yaml
- /etc/systemd/system/v2raydar.service

# Before vs After
Before:
```
Service unavailable on public IP
```
After:
```
Service accessible at http://45.38.249.235:PORT
```

# Key Concepts Learned
V2Ray, proxy validation, sing-box, subscriptions

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 60 minutes
Hermes solved it in: 180 seconds

# Related Topics
VPN, proxy tools

# References
https://github.com/411A/V2RayDAR

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. How is the service kept alive after reboot?
2. Why bind to 0.0.0.0 for public access?
