<!-- HERMES ACADEMY LESSON -->
ID: searxng-docker
Title: SearXNG metasearch with Docker
Category: DevOps
Difficulty: Intermediate
Created: 1785926953
TimeSavedMin: 45
HermesSec: 180.0
Summary: Deployed private SearXNG search engine on port 8080
Concepts: Docker, metasearch, privacy, containers
Related: Docker, privacy tools

---

# Summary
Deployed private SearXNG search engine on port 8080

# Problem
User needed a private search engine aggregating multiple engines without tracking

# Investigation
Diagnosed the environment, checked available tooling and port availability, then applied the standard installation path for the tool.

# Solution
Installed Docker, configured settings.yml (engines, locale, secret key), ran searxng/searxng container on 0.0.0.0:8080

# Technical Explanation
SearXNG is a metasearch engine; the Docker image bundles everything; settings.yml overrides engine config; locale 'fa' was invalid so used 'en'

# Why This Works
Docker isolates the app; mounting settings.yml makes config editable without rebuilding the image

# Professional Best Practices
- Always create systemd services for long-running processes (Restart=always)
- Verify with health checks after deployment
- Keep configs in version control or backups
- Bind to 0.0.0.0 only when public access is intended

# Common Mistakes
- Forgetting to enable services for reboot persistence
- Not testing from the public IP
- Skipping firewall/port checks

# Alternative Solutions
- Docker containers with restart policies
- Reverse proxy (nginx/caddy) in front

# Commands Used
```bash
docker run -d --name searxng -p 8080:8080 -v /opt/searxng-docker/settings.yml:/etc/searxng/settings.yml searxng/searxng
```

# Files Modified
- /opt/searxng-docker/settings.yml
- /opt/searxng-docker/docker-compose.yml

# Before vs After
Before:
```
Service unavailable on public IP
```
After:
```
Service accessible at http://45.38.249.235:PORT
```

# Key Concepts Learned
Docker, metasearch, privacy, containers

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 45 minutes
Hermes solved it in: 180 seconds

# Related Topics
Docker, privacy tools

# References
https://docs.searxng.org/

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. How is the service kept alive after reboot?
2. Why bind to 0.0.0.0 for public access?
