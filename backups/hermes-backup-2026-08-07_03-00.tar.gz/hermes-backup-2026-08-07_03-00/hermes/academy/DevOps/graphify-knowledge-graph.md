<!-- HERMES ACADEMY LESSON -->
ID: graphify-knowledge-graph
Title: Graphify codebase knowledge graphs
Category: DevOps
Difficulty: Intermediate
Created: 1785926953
TimeSavedMin: 40
HermesSec: 180.0
Summary: Generated knowledge graphs for HaveAll, V2RayDAR, SearXNG codebases
Concepts: knowledge graph, AST, tree-sitter, code analysis
Related: AI tooling, code analysis

---

# Summary
Generated knowledge graphs for HaveAll, V2RayDAR, SearXNG codebases

# Problem
User wanted every project mapped as a knowledge graph for agents

# Investigation
Diagnosed the environment, checked available tooling and port availability, then applied the standard installation path for the tool.

# Solution
Installed via pipx, ran graphify extract --code-only on each project, outputs graph.html/graph.json/GRAPH_REPORT.md

# Technical Explanation
Graphify parses code with tree-sitter AST (no LLM for code), builds a real graph of nodes/edges/communities, supports explain/path/query

# Why This Works
AST-based extraction is deterministic and free; --code-only skips docs/images needing an LLM

# Professional Best Practices
- Always create systemd services for long-running processes (Restart=always)
- Verify with health checks after deployment
- Keep configs in version control or backups
- Bind to 0.0.0.0 only when public access is intended

# Common Mistakes
- Forgetting to enable services for reboot persistence
- Not testing from the public IP
- Skipping firewall/port checks

# Alternative Solutions
- Docker containers with restart policies
- Reverse proxy (nginx/caddy) in front

# Commands Used
```bash
pipx install graphifyy; graphify extract /opt/HaveAll --code-only --out /root/graphify-haveall; graphify explain 'APIRouter'
```

# Files Modified
- graphify-out/graph.json per project

# Before vs After
Before:
```
Service unavailable on public IP
```
After:
```
Service accessible at http://45.38.249.235:PORT
```

# Key Concepts Learned
knowledge graph, AST, tree-sitter, code analysis

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 40 minutes
Hermes solved it in: 180 seconds

# Related Topics
AI tooling, code analysis

# References
https://github.com/Graphify-Labs/graphify

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. How is the service kept alive after reboot?
2. Why bind to 0.0.0.0 for public access?
