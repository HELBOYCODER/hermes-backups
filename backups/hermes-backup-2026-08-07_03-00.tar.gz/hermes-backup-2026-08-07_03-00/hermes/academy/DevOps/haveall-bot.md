<!-- HERMES ACADEMY LESSON -->
ID: haveall-bot
Title: HaveAll Telegram VPN bot with Supabase
Category: DevOps
Difficulty: Intermediate
Created: 1785926953
TimeSavedMin: 60
HermesSec: 180.0
Summary: Deployed HaveAll Telegram bot scraping VPN configs every 30 min
Concepts: Telegram bot, Supabase, PostgREST, scraping
Related: Telegram, Supabase, VPN

---

# Summary
Deployed HaveAll Telegram bot scraping VPN configs every 30 min

# Problem
User needed a Telegram bot providing MTProto proxies and VPN configs

# Investigation
Diagnosed the environment, checked available tooling and port availability, then applied the standard installation path for the tool.

# Solution
Cloned repo, wrote .env (BOT_TOKEN, ADMIN_IDS, SUPABASE_URL, SUPABASE_KEY), built Docker image, created Supabase tables via psql, ran container

# Technical Explanation
The old supabase Python lib rejects new sb_secret_ keys, so replaced it with a custom REST client (supabase_rest.py); tables created via psql from setup_supabase.sql

# Why This Works
New Supabase key format needs REST API directly; the bot polls Telegram every 30 min and scrapes subscriptions into Postgres

# Professional Best Practices
- Always create systemd services for long-running processes (Restart=always)
- Verify with health checks after deployment
- Keep configs in version control or backups
- Bind to 0.0.0.0 only when public access is intended

# Common Mistakes
- Forgetting to enable services for reboot persistence
- Not testing from the public IP
- Skipping firewall/port checks

# Alternative Solutions
- Docker containers with restart policies
- Reverse proxy (nginx/caddy) in front

# Commands Used
```bash
docker build -t haveall_bot .; docker run -d --name haveall_telegram_bot --env-file .env haveall_bot; psql -h db.qpuifeiisogkwpqklhwd.supabase.co -U postgres -f setup_supabase.sql
```

# Files Modified
- /opt/HaveAll/telegram_bot/.env
- /opt/HaveAll/telegram_bot/supabase_rest.py

# Before vs After
Before:
```
Service unavailable on public IP
```
After:
```
Service accessible at http://45.38.249.235:PORT
```

# Key Concepts Learned
Telegram bot, Supabase, PostgREST, scraping

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 60 minutes
Hermes solved it in: 180 seconds

# Related Topics
Telegram, Supabase, VPN

# References
https://github.com/v3ndettaaa/HaveAll

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. How is the service kept alive after reboot?
2. Why bind to 0.0.0.0 for public access?
