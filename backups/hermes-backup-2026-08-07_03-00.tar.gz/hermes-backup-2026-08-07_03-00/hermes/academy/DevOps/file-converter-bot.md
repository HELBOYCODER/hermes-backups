<!-- HERMES ACADEMY LESSON -->
ID: file-converter-bot
Title: Telegram file converter bot
Category: DevOps
Difficulty: Intermediate
Created: 1785926953
TimeSavedMin: 50
HermesSec: 180.0
Summary: Deployed Telegram bot converting audio/image/video/docs via ffmpeg + LibreOffice
Concepts: Telegram bot, ffmpeg, LibreOffice, file conversion
Related: Telegram, media processing

---

# Summary
Deployed Telegram bot converting audio/image/video/docs via ffmpeg + LibreOffice

# Problem
User needed a bot that converts any file format and sends it back without storing files

# Investigation
Diagnosed the environment, checked available tooling and port availability, then applied the standard installation path for the tool.

# Solution
Wrote bot.py (python-telegram-bot), installed ffmpeg/ImageMagick/LibreOffice/Pillow, created systemd service, temp files deleted after send

# Technical Explanation
The bot downloads to /tmp, shows format options via inline keyboard, converts (ffmpeg for media, LibreOffice for docs), sends back, then rmtree() deletes everything

# Why This Works
Video→audio uses ffmpeg -vn extraction; filters.ALL handles all media types; cleanup guarantees no disk accumulation

# Professional Best Practices
- Always create systemd services for long-running processes (Restart=always)
- Verify with health checks after deployment
- Keep configs in version control or backups
- Bind to 0.0.0.0 only when public access is intended

# Common Mistakes
- Forgetting to enable services for reboot persistence
- Not testing from the public IP
- Skipping firewall/port checks

# Alternative Solutions
- Docker containers with restart policies
- Reverse proxy (nginx/caddy) in front

# Commands Used
```bash
python3 /opt/file-converter-bot/bot.py; systemctl start file-converter-bot; ffmpeg -y -i in.mp4 -vn out.mp3
```

# Files Modified
- /opt/file-converter-bot/bot.py
- /etc/systemd/system/file-converter-bot.service

# Before vs After
Before:
```
Service unavailable on public IP
```
After:
```
Service accessible at http://45.38.249.235:PORT
```

# Key Concepts Learned
Telegram bot, ffmpeg, LibreOffice, file conversion

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 50 minutes
Hermes solved it in: 180 seconds

# Related Topics
Telegram, media processing

# References
https://core.telegram.org/bots/api

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. How is the service kept alive after reboot?
2. Why bind to 0.0.0.0 for public access?
