<!-- HERMES ACADEMY LESSON -->
ID: hermes-watchdog
Title: Hermes Agent watchdog with systemd timer
Category: DevOps
Difficulty: Intermediate
Created: 1785926953
TimeSavedMin: 30
HermesSec: 180.0
Summary: Set up always-on Hermes gateway with auto-restart watchdog
Concepts: systemd, timers, watchdog, process monitoring
Related: systemd, high availability

---

# Summary
Set up always-on Hermes gateway with auto-restart watchdog

# Problem
Hermes could crash and go offline with no automatic recovery

# Investigation
Diagnosed the environment, checked available tooling and port availability, then applied the standard installation path for the tool.

# Solution
Created hermes-gateway.service (Restart=always) + hermes-watchdog.timer checking every 60s

# Technical Explanation
systemd timers run a oneshot service on a schedule; the watchdog script checks if the gateway process exists and restarts it if not

# Why This Works
systemd guarantees restart on crash (Restart=always) and on boot (enable), the timer adds a second layer of health checks

# Professional Best Practices
- Always create systemd services for long-running processes (Restart=always)
- Verify with health checks after deployment
- Keep configs in version control or backups
- Bind to 0.0.0.0 only when public access is intended

# Common Mistakes
- Forgetting to enable services for reboot persistence
- Not testing from the public IP
- Skipping firewall/port checks

# Alternative Solutions
- Docker containers with restart policies
- Reverse proxy (nginx/caddy) in front

# Commands Used
```bash
systemctl enable hermes-gateway.service; systemctl enable hermes-watchdog.timer; cat /root/.hermes/scripts/watchdog.sh
```

# Files Modified
- /etc/systemd/system/hermes-gateway.service
- /etc/systemd/system/hermes-watchdog.timer
- /root/.hermes/scripts/watchdog.sh

# Before vs After
Before:
```
Service unavailable on public IP
```
After:
```
Service accessible at http://45.38.249.235:PORT
```

# Key Concepts Learned
systemd, timers, watchdog, process monitoring

# Difficulty
Intermediate

# Time Saved
Estimated manual debugging time: 30 minutes
Hermes solved it in: 180 seconds

# Related Topics
systemd, high availability

# References
https://www.freedesktop.org/software/systemd/man/

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. How is the service kept alive after reboot?
2. Why bind to 0.0.0.0 for public access?
