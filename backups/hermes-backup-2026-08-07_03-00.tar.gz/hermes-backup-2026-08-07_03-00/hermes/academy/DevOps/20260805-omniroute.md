<!-- HERMES ACADEMY LESSON -->
ID: omniroute-20260805
Title: Deployed OmniRoute AI Gateway on public server
Category: DevOps
Difficulty: Beginner
Created: 1785906000
TimeSavedMin: 30.0
HermesSec: 120.0
Summary: Installed OmniRoute AI gateway and exposed it on the server public IP
Concepts: AI gateway, systemd, networking, 0.0.0.0 binding
Related: systemd services, port forwarding

---

# Summary
Installed OmniRoute (AI gateway with 268 providers) via npm and served it on the public server IP.

# Problem
User needed an AI gateway accessible from any browser using the server's public IP, not just locally.

# Investigation
Checked available ports, found the default bind was localhost only, and located the `OMNIROUTE_SERVER_HOST` environment variable.

# Solution
1. Installed: `npm install -g omniroute`
2. Started with: `OMNIROUTE_SERVER_HOST=0.0.0.0 omniroute serve --port 20128 --no-open`
3. Created systemd service for auto-restart
4. Verified listening on 0.0.0.0:20128

# Technical Explanation
By default the gateway binds to 127.0.0.1 (loopback). Setting `OMNIROUTE_SERVER_HOST=0.0.0.0` binds to all interfaces so the server's public IP can reach it. A systemd unit ensures it restarts on reboot.

# Why This Works
0.0.0.0 means "all IPv4 addresses on this host" — traffic arriving on any interface (including the public one) reaches the service.

# Professional Best Practices
- Always create systemd services for long-running processes
- Use `Restart=always` for resilience
- Verify with `ss -tlnp` after binding

# Common Mistakes
- Forgetting to change the bind address, leaving the service localhost-only
- Not enabling the service for reboot persistence

# Alternative Solutions
- Docker container with port mapping
- Reverse proxy (nginx) in front

# Commands Used
```bash
npm install -g omniroute
OMNIROUTE_SERVER_HOST=0.0.0.0 omniroute serve --port 20128 --no-open
systemctl enable omniroute.service
ss -tlnp | grep 20128
```

# Files Modified
- /etc/systemd/system/omniroute.service
- /root/.omniroute/.env

# Before vs After
Before:
```
curl localhost:20128 → works, but public IP → connection refused
```
After:
```
curl http://45.38.249.235:20128 → 200 OK
```

# Key Concepts Learned
✔ AI gateway deployment
✔ systemd service management
✔ Network binding (0.0.0.0)

# Difficulty
Beginner

# Time Saved
Estimated manual debugging time: 30.0 minutes
Hermes solved it in: 120 seconds

# Related Topics
- systemd unit files
- Reverse proxies

# References
- https://omniroute.online/

# Visual Timeline
1. Problem Detected
2. Diagnosis
3. Investigation
4. Root Cause
5. Solution
6. Verification
7. Knowledge Generated

# Quiz
1. What does binding to 0.0.0.0 do?
2. Why use systemd instead of a background process?
