---
name: telegram-bot-python
description: "Use when building or debugging Python Telegram bots."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [telegram, bot, python-telegram-bot, ptb, polling, filters, getUpdates]
  related_skills: [self-hosted-services]
---

# Telegram Bot Development (python-telegram-bot)

Build, debug, and run Telegram bots written with the `python-telegram-bot` library (PTB v20+).

## Workflow

1. **Verify the token before writing code**:
   ```bash
   curl -s https://api.telegram.org/bot<TOKEN>/getMe
   ```
   `200` + `"ok":true` = valid. `401` = wrong token; `409` = token already in use by another bot instance.
2. **Check the token is not already in use on the server**: grep for it across `/opt/*/` bot sources and check `docker ps` — two processes polling the same token will fight (see Pitfalls).
3. **Build the bot**: `Application.builder().token(TOKEN).build()`, add handlers, then
   `app.run_polling(allowed_updates=Update.ALL_TYPES)`.
4. **Run it**: `terminal(background=true)` + `notify_on_complete=true` while debugging; promote to a systemd service or Docker container once stable (see `self-hosted-services` skill).
5. **Test conversions/handlers directly** with a one-off Python script instead of restarting the bot repeatedly (faster iteration; avoids token conflicts with the running instance).

## Pitfalls

### Filters do NOT compose with `|` in PTB v20+
The filters namespace mixes classes and instance constants, and `|` composition breaks in surprising ways:

- `filters.Document` is a **class** (capital D), while `filters.AUDIO`, `filters.VIDEO`, `filters.PHOTO`, `filters.VOICE` are **instance constants**.
- `filters.Document | filters.AUDIO` → `TypeError: unsupported operand type(s) for |: 'type' and '_Audio'`
- `filters.Document() | filters.AUDIO` → `TypeError: unsupported operand type(s) for |: 'Document' and '_Audio'`

**Robust pattern — do not burn time composing filters:**
```python
app.add_handler(MessageHandler(filters.ALL, handle_file))

async def handle_file(update, context):
    m = update.message
    if m.document: ...      # file attachment
    elif m.audio: ...       # audio
    elif m.video: ...       # video
    elif m.photo: ...       # photo (list of sizes)
    elif m.voice: ...       # voice note
    else: return
```
`filters.ALL` catches every message; check `update.message.<type>` attributes inside the handler. Simple, version-proof, and the message object attributes mirror the filter names.

### `Conflict: terminated by other getUpdates request` = token already polling
This error means **another running process polls the same bot token** (a leftover background process, a Docker container, or a second bot you started with the same token). Diagnose:

```bash
ps aux | grep -E "bot.py|telegram_bot" | grep -v grep
docker ps   # containers running bots
```

Each bot needs its **own** token from @BotFather. You cannot run two bots on one token — the newer instance dies with `telegram.error.Conflict`. Fix: stop the old instance, or get a fresh token and update the new bot's `BOT_TOKEN`.

### Kill the old instance before restarting during dev
PTB keeps polling; restarting while the old process lives produces the same Conflict error. Kill via `process(action=kill)` (for Hermes-tracked background procs) or `pkill -f bot.py` first.

## References

- `references/python-telegram-bot-filters.md` — exact error transcripts and the working fix from the file-converter bot build.
